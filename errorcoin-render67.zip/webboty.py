# webboty.py - Web Dashboard + Vòng quay (Flask) — chạy CHUNG tiến trình với boty.py
# Không đọc/ghi data.json trực tiếp: mọi thứ đi qua `bridge` (boty.WebBridge) => không xung đột dữ liệu.
import time, hmac, html, traceback
from datetime import timedelta
from flask import Flask, request, jsonify, session, redirect, Response
from werkzeug.exceptions import HTTPException
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired

# ============================================================
# TEMPLATES (chuỗi thô, thay placeholder __X__ — không dùng Jinja)
# ============================================================
BASE_CSS = r"""
*{margin:0;padding:0;box-sizing:border-box;font-family:'Segoe UI',system-ui,sans-serif}
body{background:#0f0f23;color:#fff;min-height:100vh}
a{color:#8da2ff}
nav{background:#1a1a2e;padding:14px 24px;display:flex;justify-content:space-between;align-items:center;box-shadow:0 2px 10px rgba(0,0,0,.5);gap:12px;flex-wrap:wrap}
nav h1{color:#667eea;font-size:21px}
button,.btn{cursor:pointer;border:none;border-radius:8px;font-weight:600;color:#fff;background:#667eea;padding:9px 16px;font-size:14px;text-decoration:none;display:inline-block}
button.red{background:#e74c3c}button.green{background:#1fa971}button:disabled{opacity:.5;cursor:wait}
.container{max-width:1300px;margin:0 auto;padding:24px 16px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:16px;margin-bottom:26px}
.card{background:#1a1a2e;border-radius:14px;padding:20px;border:1px solid #2a2a4e;overflow-x:auto}
.card h2{font-size:13px;color:#667eea;margin-bottom:10px;text-transform:uppercase;letter-spacing:1px}
.stat{font-size:28px;font-weight:700;color:#00ff9f}.gold{color:#ffd700}.pink{color:#ff69b4}.cyan{color:#00bfff}.mut{color:#888;font-size:13px;margin-top:6px}
table{width:100%;border-collapse:collapse}
th{text-align:left;padding:10px 8px;color:#667eea;font-size:12px;text-transform:uppercase;border-bottom:2px solid #2a2a4e}
td{padding:10px 8px;border-bottom:1px solid #2a2a4e;font-size:14px}
tr:hover td{background:#22223a}tr.me td{background:#2b2b55}
.rank{font-weight:700;width:44px;color:#ffd700}
.badge{display:inline-block;padding:3px 10px;border-radius:6px;font-size:12px;font-weight:700}
.on{background:#00ff9f;color:#0f0f23}.off{background:#e74c3c;color:#fff}
.section{margin-bottom:34px}.section>h2{color:#667eea;margin-bottom:14px;font-size:19px;border-left:4px solid #667eea;padding-left:10px}
input,select{padding:12px;background:#1a1a2e;border:2px solid #2a2a4e;border-radius:10px;color:#fff;font-size:15px}
input:focus,select:focus{outline:none;border-color:#667eea}
.search{display:flex;gap:10px;margin-bottom:16px;flex-wrap:wrap}.search input{flex:1;min-width:200px}
.empty{color:#777;text-align:center;padding:24px;font-style:italic}
.u{background:#22223a;border-radius:10px;padding:14px;margin-top:10px}
.u .g{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:8px;margin-top:8px;font-size:14px}
.wheel-btn{background:linear-gradient(135deg,#ff69b4,#9b59b6);padding:15px 30px;border-radius:12px;font-size:18px;margin-top:8px}
.spin{display:inline-block;animation:sp .6s linear infinite}@keyframes sp{to{transform:rotate(360deg)}}
#spinResult{margin-top:16px;font-size:19px;font-weight:700;text-align:center}
code{background:#12122a;padding:1px 6px;border-radius:5px;color:#9fb0ff}
"""

COMMON_JS = r"""
const $=id=>document.getElementById(id);
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=n=>(Number(n)||0).toLocaleString('vi-VN');
const safeUrl=u=>/^https?:\/\//i.test(u||'')?u:'';
const MEDAL=['🥇','🥈','🥉'];
async function api(path,opts){
  let r;try{r=await fetch(path,opts)}catch(e){return{error:'Mất kết nối tới bot',_status:0}}
  if(r.status===401){location.href='/';return null}
  let d={};try{d=await r.json()}catch(e){}
  d._status=r.status;return d;
}
function logout(){fetch('/api/logout',{method:'POST'}).then(()=>location.href='/')}
function renderTop(id,arr,type,withGuild){
  const head={coin:'ErrorCoin',level:'Level',cat:'Mèo'}[type];
  $(id).innerHTML=`<thead><tr><th>#</th><th>User</th><th>${head}</th>${withGuild?'<th>Server</th>':''}</tr></thead><tbody>`+
   (arr.length?arr.map((x,i)=>`<tr class="${x.me?'me':''}"><td class="rank">${MEDAL[i]||(i+1)}</td><td>${esc(x.name)}${x.me?' <span class="badge on">BẠN</span>':''}</td><td><b>${
    type==='coin'?fmt(x.value)+' 🪙':type==='level'?'Lv.'+esc(x.value):esc(x.value)}</b></td>${withGuild?'<td><code>'+esc(x.guild)+'</code></td>':''}</tr>`).join('')
   :'<tr><td colspan="4" class="empty">Chưa có dữ liệu</td></tr>')+'</tbody>';
}
"""

LOGIN_PAGE = r"""<!DOCTYPE html><html lang="vi"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>ErrorCoin · Đăng nhập</title><style>
*{margin:0;padding:0;box-sizing:border-box;font-family:'Segoe UI',system-ui,sans-serif}
body{background:linear-gradient(135deg,#667eea,#764ba2);min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px}
.card{background:#fff;border-radius:20px;padding:36px;max-width:430px;width:100%;box-shadow:0 20px 60px rgba(0,0,0,.3)}
h1{color:#667eea;text-align:center;margin-bottom:6px;font-size:27px}.sub{text-align:center;color:#888;margin-bottom:22px;font-size:14px}
input{width:100%;padding:13px;border:2px solid #e0e0e0;border-radius:10px;margin-bottom:12px;font-size:15px}input:focus{outline:none;border-color:#667eea}
button{width:100%;padding:13px;background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;border:none;border-radius:10px;font-size:16px;font-weight:600;cursor:pointer}
.tabs{display:flex;gap:8px;margin-bottom:18px}.tab{flex:1;padding:10px;text-align:center;background:#f5f5f5;border-radius:10px;cursor:pointer;font-weight:600;color:#666}
.tab.active{background:linear-gradient(135deg,#667eea,#764ba2);color:#fff}.panel{display:none}.panel.active{display:block}
.err{color:#e74c3c;text-align:center;margin-top:10px;font-size:14px;min-height:18px}.tip{color:#999;font-size:12px;text-align:center;margin-top:16px;line-height:1.6}.tip a{color:#667eea}
</style></head><body><div class="card"><h1>🎮 ErrorCoin</h1><div class="sub">Discord Bot Dashboard</div>
<div class="tabs"><div class="tab active" onclick="tab(0)">👤 User</div><div class="tab" onclick="tab(1)">🔐 Admin</div></div>
<div class="panel active" id="p0"><input id="u" placeholder="Username (bot gửi qua DM / /web login)" autocomplete="username">
<input id="p" type="password" placeholder="Password" autocomplete="current-password" onkeydown="if(event.key==='Enter')loginUser()">
<button onclick="loginUser()">Đăng nhập</button><div class="err" id="e0"></div>
<div class="tip">Chưa có / quên mật khẩu? Dùng <code>/web login</code> trên Discord.<br>Server hỗ trợ: <a href="__SUPPORT__" target="_blank" rel="noopener">__SUPPORT__</a></div></div>
<div class="panel" id="p1"><input id="k" placeholder="API Key" type="password" onkeydown="if(event.key==='Enter')loginAdmin()">
<button onclick="loginAdmin()">Đăng nhập Admin</button><div class="err" id="e1"></div>
<div class="tip">API Key được in ra console của bot khi khởi động (hoặc biến môi trường <code>WEB_API_KEY</code>).</div></div></div>
<script>
function tab(i){document.querySelectorAll('.tab').forEach((t,k)=>t.classList.toggle('active',k===i));document.querySelectorAll('.panel').forEach((p,k)=>p.classList.toggle('active',k===i))}
async function post(url,body,errId){
  try{const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  const d=await r.json().catch(()=>({}));if(r.ok){location.href='/dashboard'}else{document.getElementById(errId).textContent=d.error||'Lỗi'}}
  catch(e){document.getElementById(errId).textContent='Mất kết nối tới bot'}}
function loginUser(){const u=document.getElementById('u').value,p=document.getElementById('p').value;
  if(!u||!p){document.getElementById('e0').textContent='Nhập đủ username & password';return}post('/api/login',{username:u,password:p},'e0')}
function loginAdmin(){const k=document.getElementById('k').value;
  if(!k){document.getElementById('e1').textContent='Nhập API Key';return}post('/api/login_admin',{api_key:k},'e1')}
</script></body></html>"""

USER_PAGE = r"""<!DOCTYPE html><html lang="vi"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>ErrorCoin · Dashboard</title><style>__CSS__</style></head><body>
<nav><h1>🎮 ErrorCoin</h1><div style="display:flex;gap:10px;align-items:center"><span id="who" class="mut"></span><select id="gsel" onchange="GID=this.value;loadUser()"></select><button class="red" onclick="logout()">Đăng xuất</button></div></nav>
<div class="container"><div id="msg"></div>
<div class="grid">
 <div class="card"><h2>💰 ErrorCoin</h2><div class="stat gold" id="myCoin">...</div><div class="mut" id="myCoinInfo"></div></div>
 <div class="card"><h2>⭐ Level</h2><div class="stat cyan" id="myLevel">...</div><div class="mut" id="myXp"></div></div>
 <div class="card"><h2>🐱 Mèo</h2><div class="stat pink" id="myCat">...</div><div class="mut" id="myCatInfo"></div></div>
 <div class="card"><h2>🏅 Hạng của bạn</h2><div id="myRanks" style="line-height:1.9">...</div></div>
</div>
<div class="section"><h2>🎡 Vòng quay may mắn</h2><div class="card">
 <p style="color:#aaa;margin-bottom:12px">Mỗi lượt tốn <b class="gold">__COST__ __CUR__</b> (trừ ở server đang chọn). Giải: 5% Roblox · 5% Liên Quân · 5% Free Fire · 5% +4.000 xu · 80% chúc may mắn.</p>
 <button class="wheel-btn" onclick="spin()" id="spinBtn">🎡 QUAY NGAY (-__COST__)</button><div id="spinResult"></div></div></div>
<div class="section" id="prizeBox" style="display:none"><h2>🎁 Giải của bạn</h2><div class="card"><table id="prizes"></table></div></div>
<div class="section"><h2>🏆 Top ErrorCoin</h2><div class="card"><table id="topCoin"></table></div></div>
<div class="section"><h2>⭐ Top Level</h2><div class="card"><table id="topLv"></table></div></div>
<div class="section"><h2>🐱 Top Mèo</h2><div class="card"><table id="topCat"></table></div></div>
</div><script>__JS__
let GID='';
async function loadUser(){
  const d=await api('/api/user/me'+(GID?'?gid='+encodeURIComponent(GID):''));
  if(!d)return;
  if(d.error){$('msg').innerHTML='<div class="card empty">'+esc(d.error)+'</div>';return}
  $('msg').innerHTML='';GID=d.gid;
  $('gsel').innerHTML=d.guilds.map(g=>`<option value="${esc(g.id)}" ${g.id===GID?'selected':''}>${esc(g.name)}</option>`).join('');
  $('who').textContent='👤 '+(d.name||d.username);
  $('myCoin').textContent=fmt(d.coins)+' 🪙';$('myCoinInfo').textContent='Ví '+fmt(d.wallet)+' · Bank '+fmt(d.bank);
  $('myLevel').textContent='Lv.'+d.level;$('myXp').textContent=d.xp+'/'+d.need_xp+' XP';
  $('myCat').textContent=d.cat_name||'Chưa có';$('myCatInfo').textContent=d.cat_name?`Lv.${d.cat_level} · 🔥${d.cat_streak}`:'';
  $('myRanks').innerHTML=`💰 Coin: <b>#${d.rank_coin||'-'}</b><br>⭐ Level: <b>#${d.rank_level||'-'}</b><br>🐱 Mèo: <b>#${d.rank_cat||'-'}</b><br>🎡 Đã quay: <b>${d.spun}</b> lần`;
  renderTop('topCoin',d.top_coin,'coin');renderTop('topLv',d.top_level,'level');renderTop('topCat',d.top_cat,'cat');
  $('prizeBox').style.display=d.tickets.length?'block':'none';
  $('prizes').innerHTML='<thead><tr><th>Ticket</th><th>Giải</th><th>Thời gian</th><th>Trạng thái</th></tr></thead><tbody>'+d.tickets.map(t=>`<tr><td><code>${esc(t.ticket)}</code></td><td>${esc(t.prize)}</td><td>${esc(t.time)}</td><td>${t.done?'✅ Đã trao':'⏳ Chờ owner'}</td></tr>`).join('')+'</tbody>';
}
async function spin(){
  const b=$('spinBtn'),out=$('spinResult');b.disabled=true;out.innerHTML='<span class="spin">🎡</span> Đang quay...';
  const [r]=await Promise.all([api('/api/spin',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({gid:GID})}),new Promise(z=>setTimeout(z,1200))]);
  b.disabled=false;if(!r)return;
  if(r.error){out.innerHTML='<span style="color:#e74c3c">❌ '+esc(r.error)+'</span>';return}
  out.innerHTML=`<span style="color:${r.win?'#ffd700':'#00ff9f'}">Mã <code>${esc(r.code)}</code> → <b>${esc(r.prize)}</b></span>`+
   (r.ticket?`<br><small style="color:#aaa">Ticket <code>${esc(r.ticket)}</code> — vào server hỗ trợ và đưa mã này cho chủ server để nhận acc.</small>`:'');
  loadUser();
}
loadUser();
</script></body></html>"""

ADMIN_PAGE = r"""<!DOCTYPE html><html lang="vi"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>ErrorCoin · Admin</title><style>__CSS__</style></head><body>
<nav><h1>🎮 ErrorCoin Admin</h1><div><span class="badge on">ADMIN</span> <button class="red" onclick="logout()">Đăng xuất</button></div></nav>
<div class="container">
<div class="section"><h2>📊 Tổng quan</h2><div class="grid" id="stats"></div></div>
<div class="section"><h2>🌐 Servers kết nối</h2><div class="card"><table id="servers"></table></div></div>
<div class="section"><h2>🔍 Tìm người chơi (phân theo server)</h2>
 <div class="search"><input id="q" placeholder="Nhập tên Discord / username / ID..." onkeydown="if(event.key==='Enter')searchUsers()"><select id="sf"><option value="">Tất cả server</option></select><button onclick="searchUsers()">Tìm</button></div>
 <div id="results"></div></div>
<div class="section"><h2>🎁 Ticket trúng giải <span id="tkCount" class="badge off" style="display:none"></span></h2><div class="card"><table id="tickets"></table></div></div>
<div class="section"><h2>🏆 Top ErrorCoin (toàn hệ thống)</h2><div class="card"><table id="topCoinAll"></table></div></div>
<div class="section"><h2>⭐ Top Level (toàn hệ thống)</h2><div class="card"><table id="topLvAll"></table></div></div>
<div class="section"><h2>🐱 Top Mèo (toàn hệ thống)</h2><div class="card"><table id="topCatAll"></table></div></div>
</div><script>__JS__
let SERVERS=[];
function dur(s){const d=Math.floor(s/86400),h=Math.floor(s%86400/3600),m=Math.floor(s%3600/60);return (d?d+'d ':'')+h+'h '+m+'m'}
async function loadAdmin(){
  const s=await api('/api/admin/overview');if(!s||s.error)return;
  SERVERS=s.servers;
  $('stats').innerHTML=`<div class="card"><h2>Bot</h2><div class="stat" style="color:${s.bot_online?'#00ff9f':'#e74c3c'}">${s.bot_online?'🟢 ON':'🔴 OFF'}</div><div class="mut">${s.bot_online?s.latency+'ms · uptime '+dur(s.uptime):'Đang mất kết nối Discord'}</div></div>
   <div class="card"><h2>Servers online</h2><div class="stat">${s.total_servers}</div></div>
   <div class="card"><h2>Tổng users</h2><div class="stat gold">${fmt(s.total_users)}</div></div>
   <div class="card"><h2>Web accounts</h2><div class="stat pink">${fmt(s.total_web_accounts)}</div></div>
   <div class="card"><h2>Ticket chờ trao</h2><div class="stat cyan">${s.pending_tickets}</div></div>`;
  $('servers').innerHTML='<thead><tr><th>Tên chính</th><th>Tên server</th><th>ID</th><th>Members</th><th>Trạng thái</th><th>URL</th><th></th></tr></thead><tbody>'+
   (s.servers.map(v=>`<tr><td><b>${esc(v.alias||'—')}</b></td><td>${esc(v.name)}</td><td><code>${esc(v.id)}</code></td><td>${fmt(v.members)}</td>
    <td><span class="badge ${v.online?'on':'off'}">${v.online?'ONLINE':'OFFLINE'}</span></td>
    <td>${safeUrl(v.url)?`<a class="btn" href="${esc(safeUrl(v.url))}" target="_blank" rel="noopener">🔗 Vào server</a>`:'<span class="mut">chưa có</span>'}</td>
    <td><button data-id="${esc(v.id)}" onclick="editGuild(this.dataset.id)">✏️ Sửa</button></td></tr>`).join('')||'<tr><td colspan="7" class="empty">Chưa có server</td></tr>')+'</tbody>';
  const cur=$('sf').value;
  $('sf').innerHTML='<option value="">Tất cả server</option>'+s.servers.map(v=>`<option value="${esc(v.id)}">${esc(v.alias||v.name)}</option>`).join('');$('sf').value=cur;
  renderTop('topCoinAll',s.top_coin,'coin',1);renderTop('topLvAll',s.top_level,'level',1);renderTop('topCatAll',s.top_cat,'cat',1);
}
async function editGuild(id){
  const v=SERVERS.find(x=>x.id===id);if(!v)return;
  const alias=prompt('Tên chính của server (để phân biệt):',v.alias||v.name);if(alias===null)return;
  const url=prompt('Link vào server (https://...):',v.url||'');if(url===null)return;
  const r=await api('/api/admin/guild',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({gid:id,alias:alias,url:url})});
  if(r&&r.error)alert(r.error);loadAdmin();
}
async function searchUsers(){
  const q=$('q').value.trim();if(!q)return;
  const r=await api('/api/admin/search?q='+encodeURIComponent(q)+'&gid='+encodeURIComponent($('sf').value));
  if(!r)return;const box=$('results');
  if(r.error||!r.results.length){box.innerHTML='<div class="card empty">'+esc(r.error||'Không tìm thấy người chơi nào.')+'</div>';return}
  const by={};r.results.forEach(u=>(by[u.guild_id]=by[u.guild_id]||[]).push(u));
  box.innerHTML=Object.values(by).map(list=>{const g=list[0];
    return `<div class="card" style="margin-bottom:14px"><h2>🌐 ${esc(g.alias||g.guild)} <span class="mut">(${esc(g.guild)} · ${list.length} kết quả)</span> ${safeUrl(g.url)?`<a class="btn" style="padding:4px 10px;font-size:12px" href="${esc(safeUrl(g.url))}" target="_blank" rel="noopener">Vào server</a>`:''}</h2>`+
    list.map(u=>`<div class="u"><b style="color:#9fb0ff">${esc(u.name)}</b> <code>${esc(u.discord_id)}</code> · @${esc(u.username)}
     <div class="g"><div>💰 Ví: <b class="gold">${fmt(u.coins)}</b></div><div>🏦 Bank: <b>${fmt(u.bank)}</b></div><div>⭐ Level: <b>${esc(u.level)}</b></div><div>🐱 Mèo: <b>${esc(u.cat||'-')}</b></div><div>🏯 Bang: <b>${esc(u.gang||'-')}</b></div><div>🎡 Đã quay: <b>${esc(u.spun)}</b></div></div></div>`).join('')+'</div>'}).join('');
}
async function loadTickets(){
  const r=await api('/api/admin/tickets');if(!r||r.error)return;
  const pend=r.tickets.filter(t=>!t.done).length;const c=$('tkCount');c.style.display=pend?'inline-block':'none';c.textContent=pend+' chờ';
  $('tickets').innerHTML='<thead><tr><th>Ticket</th><th>User</th><th>Server</th><th>Giải</th><th>Mã</th><th>Thời gian</th><th></th></tr></thead><tbody>'+
   (r.tickets.map(t=>`<tr><td><code>${esc(t.ticket)}</code></td><td>${esc(t.username)} <code>${esc(t.discord_id)}</code></td><td>${esc(t.guild_name)}</td><td><b>${esc(t.prize)}</b></td><td><code>${esc(t.code)}</code></td><td>${esc(t.time)}</td>
    <td>${t.done?'✅':`<button class="green" data-t="${esc(t.ticket)}" onclick="doneTicket(this.dataset.t)">Đã trao</button>`}</td></tr>`).join('')||'<tr><td colspan="7" class="empty">Chưa có ticket</td></tr>')+'</tbody>';
}
async function doneTicket(t){await api('/api/admin/ticket_done',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({ticket:t})});loadTickets();loadAdmin()}
loadAdmin();loadTickets();setInterval(()=>{loadAdmin();loadTickets()},30000);
</script></body></html>"""

# ============================================================
# APP FACTORY
# ============================================================
def create_app(B):
    app = Flask(__name__)
    app.secret_key = B.secret
    app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax",
                      PERMANENT_SESSION_LIFETIME=timedelta(days=7), MAX_CONTENT_LENGTH=16 * 1024)
    support = html.escape(B.config.get("support", ""), quote=True)
    cost = f"{B.config.get('wheel_cost', 1000):,}"
    cur = html.escape(B.config.get("currency", "ErrorCoin"))
    login_html = LOGIN_PAGE.replace("__SUPPORT__", support)
    user_html = USER_PAGE.replace("__CSS__", BASE_CSS).replace("__JS__", COMMON_JS).replace("__COST__", cost).replace("__CUR__", cur)
    admin_html = ADMIN_PAGE.replace("__CSS__", BASE_CSS).replace("__JS__", COMMON_JS)

    # --- chống dò mật khẩu: 8 lần sai / 5 phút / IP ---
    fails = {}
    def ip():
        return (request.headers.get("X-Forwarded-For", "").split(",")[0].strip() or request.remote_addr or "?")
    def blocked(k):
        n, t = fails.get(k, (0, 0))
        if time.time() - t >= 300: fails.pop(k, None); return False
        return n >= 8
    def fail(k):
        if len(fails) > 2000: fails.clear()
        n, _ = fails.get(k, (0, 0)); fails[k] = (n + 1, time.time())

    ser = URLSafeTimedSerializer(B.secret, salt="user-token")

    def is_admin():
        if session.get("is_admin"): return True
        k = request.headers.get("X-API-Key", "")
        return bool(k) and hmac.compare_digest(k.encode(), B.api_key.encode())

    def current_user():
        """Người chơi đăng nhập bằng cookie (web trong bot) hoặc Bearer token (trang Netlify)."""
        uid = session.get("user_id")
        if uid: return uid
        h = request.headers.get("Authorization", "")
        if h.startswith("Bearer "):
            try: return ser.loads(h[7:].strip(), max_age=7 * 86400)
            except (BadSignature, SignatureExpired): return None
        return None

    origins = B.config.get("origins", "*") or "*"

    @app.before_request
    def preflight():
        if request.method == "OPTIONS" and request.path.startswith("/api/"):
            return Response("", 204)

    def page(h): return Response(h, mimetype="text/html")

    @app.after_request
    def headers(r):
        r.headers["X-Content-Type-Options"] = "nosniff"
        r.headers["X-Frame-Options"] = "DENY"
        r.headers["Referrer-Policy"] = "no-referrer"
        r.headers["Cache-Control"] = "no-store"
        if request.path.startswith("/api/"):      # cho phép trang Netlify (domain khác) gọi API; xác thực bằng header, không dùng cookie
            r.headers["Access-Control-Allow-Origin"] = origins
            r.headers["Access-Control-Allow-Headers"] = "Content-Type, X-API-Key, Authorization"
            r.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
            r.headers["Access-Control-Max-Age"] = "600"
        return r

    @app.errorhandler(Exception)
    def on_error(e):
        if isinstance(e, HTTPException): return e
        traceback.print_exc()
        return jsonify({"error": "Bot đang bận hoặc chưa sẵn sàng, thử lại sau."}), 503

    @app.get("/ping")
    def ping(): return "ok"

    @app.get("/")
    def index():
        if session.get("user_id") or session.get("is_admin"): return redirect("/dashboard")
        return page(login_html)

    @app.get("/dashboard")
    def dashboard():
        if session.get("is_admin"): return page(admin_html)
        if session.get("user_id"): return page(user_html)
        return redirect("/")

    # ---------------- AUTH ----------------
    @app.post("/api/login")
    def api_login():
        k = "u:" + ip()
        if blocked(k): return jsonify({"error": "Thử sai quá nhiều lần, đợi 5 phút nhé."}), 429
        d = request.get_json(silent=True) or {}
        username = str(d.get("username", "")).strip().lower()
        password = str(d.get("password", "")).strip()
        acc = B.account(username) if username else None
        if not acc or not B.check_pw(password, acc["pw_hash"]):
            fail(k); return jsonify({"error": "Sai tài khoản hoặc mật khẩu"}), 401
        fails.pop(k, None)
        session.clear(); session["user_id"] = acc["uid"]; session.permanent = True
        return jsonify({"ok": True, "token": ser.dumps(acc["uid"])})

    @app.get("/api/ping")
    def api_ping(): return jsonify({"ok": True})

    @app.post("/api/login_admin")
    def api_login_admin():
        k = "a:" + ip()
        if blocked(k): return jsonify({"error": "Thử sai quá nhiều lần, đợi 5 phút nhé."}), 429
        d = request.get_json(silent=True) or {}
        key = str(d.get("api_key", ""))
        if not hmac.compare_digest(key.encode(), B.api_key.encode()):
            fail(k); return jsonify({"error": "API Key sai"}), 401
        fails.pop(k, None)
        session.clear(); session["is_admin"] = True; session.permanent = True
        return jsonify({"ok": True})

    @app.post("/api/logout")
    def api_logout():
        session.clear(); return jsonify({"ok": True})

    # ---------------- USER ----------------
    @app.get("/api/user/me")
    def api_user_me():
        uid = current_user()
        if not uid: return jsonify({"error": "Unauthorized"}), 401
        return jsonify(B.me(uid, request.args.get("gid") or None))

    @app.post("/api/spin")
    def api_spin():
        uid = current_user()
        if not uid: return jsonify({"error": "Unauthorized"}), 401
        gid = str((request.get_json(silent=True) or {}).get("gid", "")).strip()
        if not gid.isdigit(): return jsonify({"error": "Chưa chọn server"}), 400
        r = B.spin(uid, gid)
        return jsonify(r), (400 if r.get("error") else 200)

    # ---------------- ADMIN ----------------
    @app.get("/api/admin/overview")
    def api_admin_overview():
        if not is_admin(): return jsonify({"error": "Unauthorized"}), 401
        return jsonify(B.overview())

    @app.get("/api/admin/search")
    def api_admin_search():
        if not is_admin(): return jsonify({"error": "Unauthorized"}), 401
        return jsonify({"results": B.search(request.args.get("q", ""), request.args.get("gid", ""))})

    @app.post("/api/admin/guild")
    def api_admin_guild():
        if not is_admin(): return jsonify({"error": "Unauthorized"}), 401
        d = request.get_json(silent=True) or {}
        ok = B.set_guild(str(d.get("gid", "")), d.get("alias"), d.get("url"))
        return (jsonify({"ok": True}), 200) if ok else (jsonify({"error": "Server không tồn tại hoặc URL không hợp lệ (cần http/https)"}), 400)

    @app.get("/api/admin/tickets")
    def api_admin_tickets():
        if not is_admin(): return jsonify({"error": "Unauthorized"}), 401
        return jsonify({"tickets": B.tickets()})

    @app.post("/api/admin/ticket_done")
    def api_admin_ticket_done():
        if not is_admin(): return jsonify({"error": "Unauthorized"}), 401
        ok = B.ticket_done(str((request.get_json(silent=True) or {}).get("ticket", "")).upper())
        return (jsonify({"ok": True}), 200) if ok else (jsonify({"error": "Không tìm thấy ticket"}), 404)

    return app
