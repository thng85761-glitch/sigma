# boty.py - Discord Bot v5.0 (Groups · 100+ lệnh · ErrorCoin · Web dashboard tích hợp · nhẹ RAM cho Pella)
# Bot + Web chạy CHUNG 1 tiến trình: web đọc/ghi dữ liệu thông qua event-loop của bot
# => không còn xung đột ghi data.json, không cần filelock, chỉ tốn 1 process.
import os, json, random, datetime, asyncio, time, re, gc, atexit, traceback, secrets
import hashlib, hmac, unicodedata, threading, concurrent.futures, shutil, copy, heapq, base64, zlib, sys, signal
import discord
from discord import app_commands
from discord.ext import tasks
from datetime import timezone, timedelta

BASE_DIR  = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(BASE_DIR, "data.json")

# ============================================================
# ⚙️ CONFIG
# ============================================================
def _load_token():
    t = os.environ.get("DISCORD_TOKEN", "").strip()
    if t: return t
    p = os.path.join(BASE_DIR, "token.txt")
    if os.path.exists(p):
        with open(p, "r", encoding="utf-8") as f: return f.read().strip()
    return ""   # ⚠️ KHÔNG hardcode token ở đây!

OWNER_ID       = int(os.environ.get("OWNER_ID", "0") or 0)
WEB_API_KEY    = os.environ.get("WEB_API_KEY", "").strip()          # để trống => tự sinh & lưu trong data.json
WEB_URL        = (os.environ.get("WEB_URL") or os.environ.get("RENDER_EXTERNAL_URL") or "").strip().rstrip("/")   # Render tự đặt RENDER_EXTERNAL_URL
WEB_PORT       = int(os.environ.get("PORT") or os.environ.get("SERVER_PORT") or 5000)
SUPPORT_INVITE = "https://discord.gg/U4GHyNURN"
WHEEL_COST     = 1000
WHEEL_COIN_PRIZE = 4000
CURRENCY       = "🪙 ErrorCoin"
VN_TZ          = timezone(timedelta(hours=7))

# (xác suất tích lũy, mã, loại, tên giải, coin) — 5% Roblox · 5% Liên Quân · 5% Free Fire · 5% +4000 xu · 80% chúc may mắn
WHEEL_PRIZES = [
    (0.05, "CUHAJS", "roblox",   "1 ACC ROBLOX",    0),
    (0.10, "HIJKOU", "lienquan", "1 ACC LIÊN QUÂN", 0),
    (0.15, "MOAUSS", "freefire", "1 ACC FREE FIRE", 0),
    (0.20, "LLOUAS", "coins",    f"+{WHEEL_COIN_PRIZE:,} {CURRENCY}", WHEEL_COIN_PRIZE),
    (0.60, "UIAUIA", "none",     "CHÚC MAY MẮN 🍀", 0),
    (1.00, "AIUAIU", "none",     "CHÚC MAY MẮN 🍀", 0),
]
_rng = random.SystemRandom()

BANNED_WORDS = ["địt","đm","vcl","dcm","đcm","fuck","shit","cunt","đĩ","súc vật"]
BANNED_RE = re.compile(r"(?<!\w)(" + "|".join(re.escape(w) for w in BANNED_WORDS) + r")(?!\w)")
TOXIC_PATTERNS = [
    (re.compile(r"\b(ngu|ngốc|khờ|đần|dốt|óc chó|vô học)\b"), 25),
    (re.compile(r"\b(mất dạy|hỗn láo|vô văn hóa|rác rưởi)\b"), 30),
    (re.compile(r"\b(cút|biến|im mồm|im đi|câm mồm)\b"), 25),
]
VIOLENCE_PATTERNS = [(re.compile(r"(giết|chém|đâm|bắn|đánh|đập).{0,20}(mày|nó|hắn|ai đó|chết)"), 70)]
URL_RE = re.compile(r"https?://[^\s]+|www\.[^\s]+")
SCAM_DOMAINS = ["steamcommunlty","discord-nitro","free-nitro","nitro-gift","free-robux","robux-free"]
SHORTENER_DOMAINS = ["bit.ly","tinyurl","cutt.ly","shorturl","t.co"]
SUSPICIOUS_KW = ["free","nitro","gift","claim","reward","hack","cheat"]

SPECIAL_ROLE_AMATERASU = "amaterasu💖"
SPECIAL_ROLE_YAMATE = "yamate kudashi🤑"
SPECIAL_ROLE_TSUKUYOMI = "tsukuyomi🌙"
SPECIAL_ROLE_SUSANOO = "susanoo⚡"
SPECIAL_ROLE_IZANAMI = "izanami💀"
WORDLE_HINT_PRICE = 50

COLORS = {"primary":0x2B2D31,"success":0x00FF7F,"danger":0xFF0033,"warning":0xFFD700,
          "info":0x00BFFF,"purple":0x9B59B6,"pink":0xFF69B4,"gold":0xFFD700,"cyan":0x00FFFF,"dark":0x2C3E50}

BOSS_NAMES = ["🐉 Rồng Lửa Cổ Đại","😈 Quỷ Vương Bóng Tối","🗿 Golem Đá Ngàn Năm",
              "🐙 Thủy Quái Biển Sâu","👻 Bóng Ma Vô Hình","💀 Tử Thần Hắc Ám"]
SHOP = {"hat":{"name":"Mũ cao bồi 🤠","price":200},"bow":{"name":"Nơ hồng 🎀","price":150},
        "glass":{"name":"Kính râm 😎","price":250},"scarf":{"name":"Khăn quàng 🧣","price":180},
        "cape":{"name":"Áo choàng 🦸","price":400},"crown":{"name":"Vương miện 👑","price":500},
        "halo":{"name":"Vòng hào quang 😇","price":800},"wings":{"name":"Cánh thiên thần 🪽","price":1200}}
OUTFIT_EMOJI = {"none":"🐱","hat":"🤠","bow":"🎀","glass":"😎","scarf":"🧣","cape":"🦸","crown":"👑","halo":"😇","wings":"🪽"}

WORDLE_WORDS = ["APPLE","BEACH","CLOUD","DANCE","EAGLE","FLAME","GRAPE","HOUSE","JUICE","KNIFE",
                "LEMON","MONEY","NOBLE","OCEAN","PIANO","QUEEN","RADIO","SUGAR","TIGER","UNION",
                "VOICE","WATER","YOUTH","ZEBRA"]
TRIVIA = [
    {"q":"Thủ đô của Pháp là gì?","a":["Paris","London","Berlin","Rome"],"correct":0},
    {"q":"Con vật nào gọi là 'chúa sơn lâm'?","a":["Hổ","Sư tử","Voi","Báo"],"correct":0},
    {"q":"1 + 1 = ?","a":["1","2","3","4"],"correct":1},
    {"q":"Hành tinh nào gần Mặt Trời nhất?","a":["Sao Kim","Sao Thủy","Trái Đất","Sao Hỏa"],"correct":1},
    {"q":"Sông nào dài nhất Việt Nam?","a":["Sông Hồng","Sông Mê Kông","Sông Đà","Sông Cầu"],"correct":1},
    {"q":"Thủ đô của Nhật Bản?","a":["Osaka","Kyoto","Tokyo","Nagoya"],"correct":2},
    {"q":"Nước nào có diện tích lớn nhất thế giới?","a":["Mỹ","Trung Quốc","Canada","Nga"],"correct":3},
    {"q":"Một năm có bao nhiêu tháng có 31 ngày?","a":["5","6","7","8"],"correct":2},
    {"q":"Nguyên tố hóa học có ký hiệu O là gì?","a":["Vàng","Oxy","Bạc","Sắt"],"correct":1},
    {"q":"Đại dương lớn nhất thế giới?","a":["Đại Tây Dương","Ấn Độ Dương","Thái Bình Dương","Bắc Băng Dương"],"correct":2},
]
BALL8 = ["✅ Chắc chắn rồi!","✅ Không nghi ngờ gì!","🟢 Có vẻ là vậy.","🟡 Không rõ nữa...",
         "🔴 Đừng trông chờ.","🔴 Chắc chắn không!"]

ACHIEVEMENTS = {
    "first_daily":{"name":"🌅 Khởi Đầu","desc":"Điểm danh lần đầu","reward":50},
    "rich_10k":{"name":"💎 Đại Gia","desc":"Có 10,000 ErrorCoin","reward":500},
    "level_10":{"name":"⭐ Chiến Binh","desc":"Đạt level 10","reward":200},
    "fish_10":{"name":"🎣 Ngư Phủ","desc":"Câu được 10 cá","reward":150},
    "robber":{"name":"🥷 Đạo Tặc","desc":"Cướp thành công lần đầu","reward":100},
    "boss_slayer":{"name":"⚔️ Sát Thủ Boss","desc":"Hạ gục World Boss","reward":300},
    "web_spin":{"name":"🎡 Cờ Bạc","desc":"Quay vòng quay web lần đầu","reward":100},
}
QUEST_POOL = [
    {"id":"work1","desc":"Làm việc `/eco work` 1 lần","type":"work","goal":1,"reward":100},
    {"id":"fish3","desc":"Câu cá 3 lần","type":"fish","goal":3,"reward":120},
    {"id":"game3","desc":"Chơi 3 game bất kỳ","type":"game","goal":3,"reward":150},
    {"id":"chat20","desc":"Nhắn 20 tin nhắn","type":"chat","goal":20,"reward":80},
]
FISH_POOL = [("🐟 Cá rô",10),("🐠 Cá vàng",15),("🦀 Cua",18),("🦞 Tôm hùm",40),("🦈 Cá mập nhỏ",80),("🎁 Rương kho báu",200)]
MINE_POOL = [("🪨 Đá",5),("⛏️ Quặng sắt",15),("🥈 Bạc",35),("🥇 Vàng",60),("💎 Kim cương",150)]
HUNT_POOL = [("🐇 Thỏ",10),("🦊 Cáo",20),("🐺 Sói",50),("🐯 Hổ",120),("🐉 Rồng nhỏ",300)]
CARD_EMOJI = {1:"🅰️",11:"🅰️",2:"2️⃣",3:"3️⃣",4:"4️⃣",5:"5️⃣",6:"6️⃣",7:"7️⃣",8:"8️⃣",9:"9️⃣",10:"🔟"}
DICE_EMOJI = {1:"⚀",2:"⚁",3:"⚂",4:"⚃",5:"⚄",6:"⚅"}
MEDALS = ("🥇","🥈","🥉")

def medal(k): return MEDALS[k] if k < 3 else "▫️"

def E(desc=None, title=None, color="info"):
    return discord.Embed(title=title, description=desc,
                         color=COLORS.get(color, color) if isinstance(color, str) else color)

# Giờ Việt Nam cho mọi thứ "theo ngày" (host Pella chạy UTC)
def today_date(): return datetime.datetime.now(VN_TZ).date()
def today(): return today_date().isoformat()

# ============================================================
# 💾 DATA LAYER  (chỉ truy cập từ event-loop của bot => không cần lock)
# ============================================================
_DATA = None
_DIRTY = False

# ---- ☁️ Lưu dữ liệu ra Upstash Redis (host free như Render xóa đĩa mỗi lần khởi động lại) ----
REDIS_URL   = (os.environ.get("UPSTASH_REDIS_REST_URL") or os.environ.get("REDIS_REST_URL") or "").strip().rstrip("/")
REDIS_TOKEN = (os.environ.get("UPSTASH_REDIS_REST_TOKEN") or os.environ.get("REDIS_REST_TOKEN") or "").strip()
REDIS_KEY   = os.environ.get("REDIS_KEY", "errorcoin:data").strip()
REMOTE_ON   = bool(REDIS_URL and REDIS_TOKEN)
REMOTE_INTERVAL = 120          # giây: tối đa 1 lần đẩy / 2 phút (+ đẩy ngay khi tắt bot) -> ~720 lệnh/ngày, free có 500K/tháng
_REMOTE_DIRTY = False; _remote_last = 0.0; _remote_busy = False

def _redis(cmd, timeout=20):
    import urllib.request
    req = urllib.request.Request(REDIS_URL, data=json.dumps(cmd).encode(), method="POST",
                                 headers={"Authorization": f"Bearer {REDIS_TOKEN}", "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r: d = json.loads(r.read().decode())
    if isinstance(d, dict) and d.get("error"): raise RuntimeError(d["error"])
    return d.get("result")

def _pack(obj):   return base64.b64encode(zlib.compress(json.dumps(obj, separators=(",", ":"), ensure_ascii=False).encode(), 6)).decode()
def _unpack(txt): return json.loads(zlib.decompress(base64.b64decode(txt)).decode())

def remote_pull():
    """dict nếu Redis đã có dữ liệu, None nếu trống. Lỗi mạng/sai key -> raise."""
    txt = _redis(["GET", REDIS_KEY]); return _unpack(txt) if txt else None

def remote_flush(force=False):
    global _REMOTE_DIRTY, _remote_last, _remote_busy
    if not REMOTE_ON or _DATA is None or not _REMOTE_DIRTY: return
    now = time.time()
    if not force and (_remote_busy or now - _remote_last < REMOTE_INTERVAL): return
    snap = _pack(_DATA); _REMOTE_DIRTY = False; _remote_last = now      # chụp ngay trên luồng chính, gửi ở luồng khác
    def job():
        global _REMOTE_DIRTY, _remote_busy
        try: _redis(["SET", REDIS_KEY, snap], timeout=25)
        except Exception as e: _REMOTE_DIRTY = True; print("⚠️ Chưa đẩy được dữ liệu lên Redis (sẽ thử lại):", e)
        finally: _remote_busy = False
    if force: job()
    else: _remote_busy = True; threading.Thread(target=job, daemon=True, name="redis-push").start()

def load_data():
    global _DATA
    if _DATA is not None: return _DATA
    _DATA = {}
    if REMOTE_ON:
        remote, ok = None, False
        for k in range(4):
            try: remote = remote_pull(); ok = True; break
            except Exception as e:
                print(f"⚠️ Đọc Redis lần {k+1}/4 lỗi: {e}"); time.sleep(2 * (k + 1))
        if not ok:    # TUYỆT ĐỐI không chạy với dữ liệu rỗng rồi ghi đè lên Redis -> dừng để host tự khởi động lại
            print("❌ Không đọc được Redis (sai UPSTASH_REDIS_REST_URL/TOKEN hoặc Upstash lỗi). Dừng bot để KHÔNG làm mất dữ liệu.")
            raise SystemExit(1)
        if isinstance(remote, dict) and remote:
            _DATA = remote; print(f"☁️ Đã tải dữ liệu từ Redis ({len(remote.get('users', {}))} server)")
            try:
                with open(DATA_FILE, "w", encoding="utf-8") as f: json.dump(_DATA, f, separators=(",", ":"), ensure_ascii=False)
            except Exception: pass
            return _DATA
        print("☁️ Redis đang trống — dùng dữ liệu local (nếu có) và sẽ đẩy lên Redis.")
    if os.path.exists(DATA_FILE):
        try:
            with open(DATA_FILE, "r", encoding="utf-8") as f: _DATA = json.load(f)
            if not isinstance(_DATA, dict): raise ValueError("data.json không phải object")
            try: shutil.copy2(DATA_FILE, DATA_FILE + ".bak")
            except Exception: pass
        except Exception as e:
            print("⚠️ data.json hỏng, đã đổi tên để giữ lại:", e)
            try: os.replace(DATA_FILE, f"{DATA_FILE}.corrupt-{int(time.time())}")
            except Exception: pass
            _DATA = {}
    if REMOTE_ON: globals()["_REMOTE_DIRTY"] = True       # lần đầu: đẩy dữ liệu hiện có lên Redis
    return _DATA

def save_data(d=None):
    global _DATA, _DIRTY, _REMOTE_DIRTY
    if d is not None: _DATA = d
    _DIRTY = True; _REMOTE_DIRTY = True

def flush_data(force_remote=False):
    global _DIRTY
    if _DIRTY and _DATA is not None:
        tmp = DATA_FILE + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(_DATA, f, separators=(",", ":"), ensure_ascii=False)
            os.replace(tmp, DATA_FILE)
            _DIRTY = False
        except Exception as e: print("⚠️ Save error:", e)
    try: remote_flush(force_remote)
    except Exception as e: print("⚠️ Redis flush error:", e)

atexit.register(lambda: flush_data(True))

def _default_user():
    return {"coins":100,"bank":0,"level":1,"xp":0,"last_daily":"","last_work":0,"last_msg_xp":0,
            "last_rob":0,"last_fish":0,"last_mine":0,"last_hunt":0,"married_to":None,
            "inventory":[],"achievements":[],"afk":None,
            "stats":{"fish":0,"mine":0,"hunt":0,"boss":0,"chat":0,"games":0,"work":0},
            "quests":{"date":"","list":[],"progress":{}},"gang":None}
_DU = _default_user()

def ensure_user(guild_id, user_id):
    data = load_data()
    g = data.setdefault("users", {}).setdefault(str(guild_id), {})
    u = g.get(str(user_id))
    if u is None:
        u = g[str(user_id)] = _default_user()
    else:
        for k, v in _DU.items():
            if k not in u: u[k] = copy.deepcopy(v)
        st = u["stats"]
        if len(st) < len(_DU["stats"]):
            for sk, sv in _DU["stats"].items(): st.setdefault(sk, sv)
    return u, data

def save_user(guild_id, user_id, u, data):
    data.setdefault("users", {}).setdefault(str(guild_id), {})[str(user_id)] = u
    save_data(data)

def add_coins(guild_id, user_id, amount):
    u, d = ensure_user(guild_id, user_id)
    u["coins"] += amount
    save_user(guild_id, user_id, u, d)
    return u["coins"]

def is_admin(i): return i.user.guild_permissions.administrator
def is_owner_or_admin(i): return i.user.id == OWNER_ID or is_admin(i)
def has_special_role(i, role_name): return any(r.name == role_name for r in i.user.roles)

async def fetch_m(guild, uid):
    m = guild.get_member(uid)
    if m: return m
    try: return await guild.fetch_member(uid)
    except Exception: return None

def unlock_achievement(guild_id, user_id, ach_id):
    u, d = ensure_user(guild_id, user_id)
    if ach_id in u.get("achievements", []) or ach_id not in ACHIEVEMENTS: return None
    ach = ACHIEVEMENTS[ach_id]
    u["achievements"].append(ach_id)
    u["coins"] += ach["reward"]
    save_user(guild_id, user_id, u, d)
    return E(f"> **{ach['name']}**\n*{ach['desc']}*\n\n🎁 Phần thưởng: `+{ach['reward']}` {CURRENCY}", "🏆 THÀNH TỰU MỚI!", "gold")

def add_quest_progress(guild_id, user_id, q_type, amount=1):
    u, d = ensure_user(guild_id, user_id)
    t = today()
    q = u.setdefault("quests", {"date":"","list":[],"progress":{}})
    if q.get("date") != t:
        q["date"] = t
        q["list"] = [x["id"] for x in random.sample(QUEST_POOL, 3)]
        q["progress"] = {k: 0 for k in q["list"]}
    for qid in q["list"]:
        item = next((x for x in QUEST_POOL if x["id"] == qid), None)
        if item and item["type"] == q_type:
            q["progress"][qid] = q["progress"].get(qid, 0) + amount
    save_user(guild_id, user_id, u, d)

def get_progress_bar(current, total, length=12, color="🟩"):
    pct = int(current / total * 100) if total > 0 else 0
    pct = max(0, min(100, pct))
    filled = int(length * pct / 100)
    return f"`{pct}%` " + color * filled + "⬛" * (length - filled)

def xp_need(level): return 100 * level

# ============================================================
# 🌐 WEB ACCOUNT (mật khẩu được BĂM, không lưu dạng thô)
# ============================================================
def hash_pw(pw, salt=None):
    salt = salt or secrets.token_hex(8)
    return f"{salt}${hashlib.pbkdf2_hmac('sha256', pw.encode(), salt.encode(), 60000).hex()}"

def check_pw(pw, stored):
    try: salt, h = stored.split("$", 1)
    except Exception: return False
    return hmac.compare_digest(hash_pw(pw, salt).split("$", 1)[1], h)

def _gen_pw():
    return "".join(secrets.choice("abcdefghjkmnpqrstuvwxyz23456789") for _ in range(10))

def ensure_web_account(guild_id, discord_id, discord_name):
    """Trả (account, mật_khẩu_thô_nếu_vừa_tạo_mới_else_None)."""
    data = load_data(); web = data.setdefault("web_accounts", {}); uid = str(discord_id)
    acc = web.get(uid)
    if acc is None:
        ascii_name = unicodedata.normalize("NFKD", discord_name.lower()).encode("ascii", "ignore").decode()
        base = re.sub(r"[^a-z0-9]", "", ascii_name)[:12] or "user"
        username = f"{base}{discord_id % 10000}"
        taken = {a.get("username") for a in web.values()}
        while username in taken: username = f"{base}{random.randint(1000, 99999)}"
        pw = _gen_pw()
        web[uid] = {"username":username, "pw_hash":hash_pw(pw), "discord_id":discord_id, "discord_name":discord_name,
                    "guilds":[int(guild_id)] if guild_id else [], "created":today(), "spun":0, "last_spin":0}
        save_data(data)
        return web[uid], pw
    changed = False
    if "password" in acc:                       # nâng cấp tài khoản cũ (mật khẩu thô -> băm)
        acc["pw_hash"] = hash_pw(acc.pop("password")); changed = True
    gl = acc.setdefault("guilds", [])
    if guild_id and int(guild_id) not in gl: gl.append(int(guild_id)); changed = True
    if discord_name and acc.get("discord_name") != discord_name: acc["discord_name"] = discord_name; changed = True
    if changed: save_data(data)
    return acc, None

def reset_web_password(guild_id, discord_id, discord_name):
    acc, pw = ensure_web_account(guild_id, discord_id, discord_name)
    if pw is None:
        pw = _gen_pw(); acc["pw_hash"] = hash_pw(pw); save_data()
    return acc, pw

def cred_embed(acc, pw, title="🎁 TÀI KHOẢN WEB MỚI"):
    link = f"\n> 🔗 Web: {WEB_URL}" if WEB_URL else ""
    return E(f"> 👤 Username: `{acc['username']}`\n> 🔑 Password: `{pw}`{link}\n\n"
             f"⚠️ Mật khẩu chỉ hiện **1 lần**. Quên? Dùng `/web login` để cấp mật khẩu mới.", title, "gold")

# ============================================================
# 🏠 GUILD META (tên chính, URL vào server — hiện trên web admin)
# ============================================================
def gmeta(gid): return load_data().setdefault("guilds", {}).setdefault(str(gid), {})

async def ensure_guild_invite(guild):
    m = gmeta(guild.id)
    if m.get("name") != guild.name: m["name"] = guild.name; save_data()
    if m.get("url"): return
    me = guild.me
    if not me: return
    for ch in guild.text_channels[:5]:
        if ch.permissions_for(me).create_instant_invite:
            try:
                inv = await ch.create_invite(max_age=0, max_uses=0, unique=False, reason="Link web dashboard")
                m["url"] = inv.url; save_data(); return
            except Exception: continue

# ============================================================
# 🛡️ MODERATION
# ============================================================
mod_history, warn_tracker = {}, {}

def analyze_content(content):
    score, reasons = 0, []
    low = unicodedata.normalize("NFC", content.lower())
    m = BANNED_RE.search(low)                    # khớp nguyên từ => "đĩa" không còn bị bắt nhầm
    if m: score += 50; reasons.append(f"Từ cấm: `{m.group(1)}`")
    for pat, sev in TOXIC_PATTERNS:
        if pat.search(low): score += sev; reasons.append("Ngữ cảnh Toxic"); break
    for pat, sev in VIOLENCE_PATTERNS:
        if pat.search(low): score += sev; reasons.append("Kích động bạo lực"); break
    for url in URL_RE.findall(low):
        if any(d in url for d in SCAM_DOMAINS): score += 85; reasons.append("Link lừa đảo")
        if any(s in url for s in SHORTENER_DOMAINS) and any(kw in low for kw in SUSPICIOUS_KW):
            score += 60; reasons.append("Link rút gọn đáng ngờ")
    if len(content) > 15 and sum(1 for c in content if c.isupper())/len(content) > 0.75:
        score += 20; reasons.append("Spam CHỮ HOA")
    return min(score, 100), reasons

def check_spam(message):
    now = time.time(); key = (message.guild.id, message.author.id)
    c = message.content.lower().strip()
    h = [(t, x) for t, x in mod_history.get(key, []) if now - t < 30]
    h.append((now, c)); mod_history[key] = h
    if sum(1 for t, _ in h if now - t < 5) >= 6: return True, "Spam tốc độ"
    if len(c) > 3 and sum(1 for _, x in h if x == c) >= 3: return True, "Spam lặp lại"   # trùng ≥3 lần / 30s
    if len(message.mentions) >= 5: return True, "Spam tag"
    return False, ""

async def punish_user(message, score, reasons, spam_reason=""):
    gid, uid = message.guild.id, message.author.id
    try: await message.delete()
    except Exception: pass
    wt = warn_tracker.setdefault((gid, uid), {"count":0,"last":0})
    now = time.time()
    if now - wt["last"] > 3600: wt["count"] = 0
    wt["count"] += 1; wt["last"] = now
    minutes = 5 if spam_reason else (30 if score >= 80 else 10 if score >= 60 else 0)
    if wt["count"] >= 3: minutes = max(minutes, 30)        # vi phạm 3 lần/giờ => phạt nặng hơn
    timeout_ok = False
    if minutes > 0:
        try:
            await message.author.timeout(timedelta(minutes=minutes), reason="Vi phạm"); timeout_ok = True
        except Exception: pass
    pun = f"Timeout {minutes} phút" if timeout_ok else "Cảnh cáo"
    e = E(f"> **Đối tượng:** {message.author.mention}\n> **Hình phạt:** `{pun}`\n\n**📝 Lý do:**\n"
          + "\n".join(f"• {r}" for r in reasons[:3]), "🚨 HỆ THỐNG KIỂM DUYỆT", "danger")
    e.set_thumbnail(url=message.author.display_avatar.url)
    e.set_footer(text=f"Vi phạm {wt['count']}/3 · Auto-Mod")
    try: await message.channel.send(embed=e, delete_after=15)
    except Exception: pass

# ============================================================
# 🐱 CAT & WORDLE HELPERS
# ============================================================
def new_cat(name="Mèo con"):
    return {"name":name,"level":1,"xp":0,"hunger":100,"happiness":100,"streak":0,"last_care":"",
            "outfit":"none","born":today()}

def levelup_cat(cat):
    while cat["xp"] >= xp_need(cat["level"]):
        cat["xp"] -= xp_need(cat["level"]); cat["level"] += 1
    return cat

def get_cat(guild_id, user_id, create=True):
    data = load_data()
    gc_ = data.get("cats", {}).get(str(guild_id))
    if not gc_ or not gc_.get("channel_id"): return None, data
    cats = gc_.setdefault("cats", {}); uid = str(user_id)
    if uid not in cats:
        if not create: return None, data
        cats[uid] = new_cat(); save_data(data)
    return cats[uid], data

def save_cat(guild_id, user_id, cat, data):
    data["cats"][str(guild_id)]["cats"][str(user_id)] = cat; save_data(data)

def cat_embed(cat, user):
    emoji = OUTFIT_EMOJI.get(cat["outfit"], "🐱")
    oname = SHOP.get(cat["outfit"], {}).get("name", "Không có") if cat["outfit"] != "none" else "Không có"
    e = E(f"> 🎩 **Trang bị:** {oname}\n> 🔥 **Chuỗi ngày:** `{cat['streak']}`", f"🐾 {cat['name']} {emoji}", "pink")
    e.add_field(name="⭐ Cấp độ", value=f"`Lv.{cat['level']}`")
    e.add_field(name="✨ Kinh nghiệm", value=f"`{cat['xp']}/{xp_need(cat['level'])}`")
    e.add_field(name="🍖 Độ đói", value=get_progress_bar(cat["hunger"],100,8,"🟨"), inline=False)
    e.add_field(name="😊 Vui vẻ", value=get_progress_bar(cat["happiness"],100,8,"🟪"), inline=False)
    e.set_thumbnail(url=user.display_avatar.url)
    e.set_footer(text=f"Chủ sở hữu: {user.display_name}", icon_url=user.display_avatar.url)
    return e

def cat_action(gid, user, action):
    """Dùng chung cho nút bấm & slash. Trả (embed, lỗi). Có cooldown 20s cho feed/play chống farm XP."""
    cat, data = get_cat(gid, user.id)
    if not cat: return None, "❌ Server chưa có khu mèo! Admin dùng `/setup meonow`."
    now = int(time.time())
    if action in ("feed", "play"):
        key = "last_" + action
        if now - cat.get(key, 0) < 20: return None, f"⏰ Chờ `{20 - (now - cat[key])}s` nữa!"
        cat[key] = now
    if action == "feed":
        cat["hunger"] = min(100, cat["hunger"]+20); cat["xp"] += 15; levelup_cat(cat); save_cat(gid, user.id, cat, data)
        return E(f"🍖 **{cat['name']}** đã ăn no nê!\n> 🍖 Độ đói: `{cat['hunger']}/100`\n> ✨ `+15 XP`", color="success"), None
    if action == "play":
        cat["happiness"] = min(100, cat["happiness"]+15); cat["hunger"] = max(0, cat["hunger"]-5); cat["xp"] += 20
        levelup_cat(cat); save_cat(gid, user.id, cat, data)
        return E(f"🎾 **{cat['name']}** rất vui vẻ!\n> 😊 Vui vẻ: `{cat['happiness']}/100`\n> ✨ `+20 XP`", color="info"), None
    if action == "pet":
        t = today(); last = cat.get("last_care", "")
        if last == t: return None, f"⏰ Hôm nay đã vuốt rồi! Chuỗi: `{cat['streak']} ngày`"
        try: cat["streak"] = cat["streak"]+1 if last and (today_date() - datetime.date.fromisoformat(last)).days == 1 else 1
        except Exception: cat["streak"] = 1
        cat["last_care"] = t; gained = 25 + cat["streak"]*5; cat["xp"] += gained
        cat["happiness"] = min(100, cat["happiness"]+10); levelup_cat(cat); save_cat(gid, user.id, cat, data)
        bonus = 10 + cat["streak"]*2; add_coins(gid, user.id, bonus)
        return E(f"🤚 Bạn vuốt ve **{cat['name']}**!\n> 🔥 Chuỗi: `{cat['streak']} ngày`\n> ✨ XP: `+{gained}` | {CURRENCY}: `+{bonus}`", color="pink"), None
    return cat_embed(cat, user), None

def ensure_wordle(guild_id):
    data = load_data(); w = data.setdefault("wordle", {}); gid = str(guild_id)
    t = today()
    if gid not in w or w[gid].get("date") != t:
        w[gid] = {"date":t,"word":random.choice(WORDLE_WORDS),"guesses":{},"hints":{}}
        save_data(data)
    return w[gid], data

def wordle_result(guess, target):
    r = [None]*5; t = list(target)
    for i in range(5):
        if guess[i] == t[i]: r[i] = "🟩"; t[i] = None
    for i in range(5):
        if r[i] is None:
            if guess[i] in t: r[i] = "🟨"; t[t.index(guess[i])] = None
            else: r[i] = "⬛"
    return "".join(r)

# ============================================================
# 🏯 GANG HELPERS
# ============================================================
def get_gangs(guild_id): return load_data().setdefault("gangs", {}).setdefault(str(guild_id), {})
def find_gang(guild_id, name):
    for k, g in get_gangs(guild_id).items():
        if k.lower() == name.lower() or g["name"].lower() == name.lower(): return k, g
    return None, None
def is_gang_leader(gang, uid): return uid == gang["owner"] or uid in gang.get("vices", [])
def is_gang_member(gang, uid): return is_gang_leader(gang, uid) or uid in gang.get("members", [])

async def gang_channel_add(guild, gang, uid):
    ch = guild.get_channel(gang.get("channel_id", 0)); m = await fetch_m(guild, uid)
    if ch and m:
        try: await ch.set_permissions(m, view_channel=True, send_messages=True, read_message_history=True)
        except Exception: pass

async def gang_channel_remove(guild, gang, uid):
    ch = guild.get_channel(gang.get("channel_id", 0)); m = await fetch_m(guild, uid)
    if ch and m:
        try: await ch.set_permissions(m, overwrite=None)
        except Exception: pass

def wolf_winner(g):
    wolves = [u for u in g["alive"] if g["roles"].get(u) == "🐺 Sói"]
    vill = [u for u in g["alive"] if u not in wolves]
    if not wolves: return "🏘️ DÂN LÀNG THẮNG!"
    if len(wolves) >= len(vill): return "🐺 SÓI THẮNG!"
    return None

# ============================================================
# 🖥️ UI VIEWS
# ============================================================
class BossView(discord.ui.View):
    def __init__(self, boss_name, hp, gid):
        super().__init__(timeout=3600)
        self.boss_name, self.hp, self.max_hp, self.gid = boss_name, hp, hp, str(gid)
        self.participants, self.dead, self.last_hit = {}, False, {}
    async def on_timeout(self):
        if active_bosses.get(self.gid) is self: active_bosses.pop(self.gid, None)
    def make_embed(self):
        e = E(f"**{get_progress_bar(self.hp, self.max_hp, 20, '🟥')}**\n❤️ **HP:** `{max(0,self.hp):,}/{self.max_hp:,}`\n\n"
              f"> ⚠️ *Bấm nút bên dưới để tấn công!*\n> ⏱️ *Tồn tại tối đa 60 phút*",
              f"⚔️ WORLD BOSS: {self.boss_name.upper()}", "danger")
        if self.participants:
            top = sorted(self.participants.items(), key=lambda x: -x[1])[:3]
            lb = "\n".join(f"{medal(k)} <@{uid}> — `{dmg:,}` dmg" for k, (uid, dmg) in enumerate(top))
            e.add_field(name="🏆 TOP SÁT THƯƠNG", value=lb, inline=False)
        return e
    @discord.ui.button(label="Tấn công", style=discord.ButtonStyle.danger, emoji="🗡️")
    async def attack(self, interaction, button):
        if self.dead: return await interaction.response.send_message("💀 Boss đã bị tiêu diệt!", ephemeral=True)
        now = time.time()
        if now - self.last_hit.get(interaction.user.id, 0) < 3:
            return await interaction.response.send_message("⏰ Chờ 3s mỗi đòn đánh!", ephemeral=True)
        self.last_hit[interaction.user.id] = now
        base = random.randint(15, 40); crit = random.random() < 0.2; dmg = base*2 if crit else base
        self.hp -= dmg
        self.participants[interaction.user.id] = self.participants.get(interaction.user.id, 0) + dmg
        if self.hp <= 0:
            self.hp, self.dead = 0, True
            embed = self.make_embed(); embed.title = f"💀 BOSS BỊ HẠ GỤC: {self.boss_name}"; embed.color = COLORS["success"]
            top = sorted(self.participants.items(), key=lambda x: -x[1])[:3]; rewards = [300, 150, 75]; winners = []
            for k, (uid, _) in enumerate(top):
                add_coins(interaction.guild_id, uid, rewards[k])
                winners.append(f"{medal(k)} <@{uid}> — `+{rewards[k]} {CURRENCY}`")
                unlock_achievement(interaction.guild_id, uid, "boss_slayer")
            embed.add_field(name="🎁 PHẦN THƯỞNG", value="\n".join(winners) or "Không ai", inline=False)
            active_bosses.pop(self.gid, None); self.stop()
            await interaction.response.edit_message(embed=embed, view=None)
        else:
            await interaction.response.edit_message(embed=self.make_embed(), view=self)
            suf = " 💥 **CRITICAL HIT!**" if crit else ""
            try: await interaction.followup.send(f"⚔️ Bạn gây ra `{dmg}` sát thương!{suf}", ephemeral=True)
            except Exception: pass

class CatView(discord.ui.View):
    def __init__(self): super().__init__(timeout=None)
    async def _do(self, i, action):
        e, err = cat_action(i.guild_id, i.user, action)
        await i.response.send_message(embed=e, ephemeral=True) if e else await i.response.send_message(err, ephemeral=True)
    @discord.ui.button(label="Cho ăn", style=discord.ButtonStyle.success, custom_id="cat_feed_v3", emoji="🍖")
    async def feed(self, i, b): await self._do(i, "feed")
    @discord.ui.button(label="Chơi đùa", style=discord.ButtonStyle.primary, custom_id="cat_play_v3", emoji="🎾")
    async def play(self, i, b): await self._do(i, "play")
    @discord.ui.button(label="Vuốt ve", style=discord.ButtonStyle.secondary, custom_id="cat_pet_v3", emoji="🤚")
    async def pet(self, i, b): await self._do(i, "pet")
    @discord.ui.button(label="Xem thông tin", style=discord.ButtonStyle.danger, custom_id="cat_view_v3", emoji="👀")
    async def info(self, i, b): await self._do(i, "view")

class TriviaView(discord.ui.View):
    def __init__(self, q, reward=50):
        super().__init__(timeout=30); self.q, self.reward, self.answered = q, reward, False
        for idx, ans in enumerate(q["a"]):
            btn = discord.ui.Button(label=f"{'ABCD'[idx]}. {ans}", style=discord.ButtonStyle.primary)
            btn.callback = self.make_cb(idx); self.add_item(btn)
    def make_cb(self, idx):
        async def cb(i):
            if self.answered: return await i.response.send_message("⏰ Đã có người trả lời!", ephemeral=True)
            self.answered = True; correct = self.q["correct"]
            add_quest_progress(i.guild_id, i.user.id, "game")
            if idx == correct:
                add_coins(i.guild_id, i.user.id, self.reward)
                e = E(f"> {i.user.mention} đã trả lời đúng!\n> 🎁 Phần thưởng: `+{self.reward} {CURRENCY}`", "✅ CHÍNH XÁC!", "success")
            else:
                e = E(f"> Đáp án đúng là: **{self.q['a'][correct]}**", "❌ SAI RỒI!", "danger")
            for c in self.children: c.disabled = True
            self.stop(); await i.response.edit_message(embed=e, view=self)
        return cb

class PollView(discord.ui.View):
    EM = ["1️⃣","2️⃣","3️⃣","4️⃣","5️⃣"]
    def __init__(self, question, options):
        super().__init__(timeout=300); self.votes = {k: set() for k in range(len(options))}
        self.options, self.question = options, question
        for idx, opt in enumerate(options):
            btn = discord.ui.Button(label=opt[:70], emoji=self.EM[idx], style=discord.ButtonStyle.secondary)
            btn.callback = self.make_cb(idx); self.add_item(btn)
    def make_embed(self):
        e = E(f"> **{self.question}**\n", "📊 BÌNH CHỌN", "purple")
        total = sum(len(v) for v in self.votes.values()) or 1
        for idx, opt in enumerate(self.options):
            cnt = len(self.votes[idx])
            e.add_field(name=f"{self.EM[idx]} {opt}", value=f"{get_progress_bar(cnt,total,10,'🟪')} **{cnt}** ({int(cnt/total*100)}%)", inline=False)
        e.set_footer(text=f"Tổng: {sum(len(v) for v in self.votes.values())} phiếu · 5 phút")
        return e
    def make_cb(self, idx):
        async def cb(i):
            for s in self.votes.values(): s.discard(i.user.id)
            self.votes[idx].add(i.user.id)
            await i.response.edit_message(embed=self.make_embed(), view=self)
        return cb

class BlackjackChallenge(discord.ui.View):
    def __init__(self, challenger, opponent, bet):
        super().__init__(timeout=60); self.challenger, self.opponent, self.bet = challenger, opponent, bet
    def _embed(self, status="⏳ Đang chờ phản hồi..."):
        return E(f"⚔️ **{self.challenger.mention}** thách **{self.opponent.mention}**\n💰 Cược: `{self.bet:,}` {CURRENCY}\n\n> {status}",
                 "🎴 LỜI THÁCH BLACKJACK", "purple").set_footer(text="60s phản hồi", icon_url=self.challenger.display_avatar.url)
    @discord.ui.button(label="✅ Chấp nhận", style=discord.ButtonStyle.success)
    async def accept(self, i, b):
        if i.user.id != self.opponent.id: return await i.response.send_message("❌ Chỉ người được thách!", ephemeral=True)
        u1, _ = ensure_user(i.guild_id, self.challenger.id); u2, _ = ensure_user(i.guild_id, self.opponent.id)
        if u2.get("coins",0) < self.bet or u1.get("coins",0) < self.bet:
            return await i.response.send_message("❌ Không đủ ErrorCoin!", ephemeral=True)
        self.stop(); view = BlackjackPvP(self.challenger, self.opponent, self.bet)
        await i.response.edit_message(embed=view.make_embed(), view=view)
    @discord.ui.button(label="❌ Từ chối", style=discord.ButtonStyle.danger)
    async def decline(self, i, b):
        if i.user.id != self.opponent.id: return await i.response.send_message("❌ Chỉ người được thách!", ephemeral=True)
        self.stop(); await i.response.edit_message(embed=E(f"{self.opponent.mention} đã từ chối!", "❌ TỪ CHỐI", "danger"), view=None)

class BlackjackPvP(discord.ui.View):
    def __init__(self, p1, p2, bet):
        super().__init__(timeout=180); self.p1, self.p2, self.bet = p1, p2, bet
        self.hands = {p1.id:[self.draw(),self.draw()], p2.id:[self.draw(),self.draw()]}
        self.current = p1.id; self.finished = {p1.id:False, p2.id:False}
    def draw(self): return random.choice([1,2,3,4,5,6,7,8,9,10,10,10,10,11])
    def score(self, hand):
        t, a = sum(hand), hand.count(11)
        while t > 21 and a > 0: t -= 10; a -= 1
        return t
    def make_embed(self):
        p1s, p2s = self.score(self.hands[self.p1.id]), self.score(self.hands[self.p2.id])
        cur = self.p1 if self.current == self.p1.id else self.p2
        e = E(f"💰 Cược: `{self.bet:,}` {CURRENCY}\n🎯 Lượt: {cur.mention}\n━━━━━━━━━━━━━━━━━━━━", "🃏 BLACKJACK PvP", "purple")
        e.add_field(name=f"🎴 {self.p1.display_name}", value=f"{' '.join(CARD_EMOJI[c] for c in self.hands[self.p1.id])}\nĐiểm: `{p1s}`" + (" 💥" if p1s>21 else ""), inline=True)
        e.add_field(name=f"🎴 {self.p2.display_name}", value=f"{' '.join(CARD_EMOJI[c] for c in self.hands[self.p2.id])}\nĐiểm: `{p2s}`" + (" 💥" if p2s>21 else ""), inline=True)
        return e
    @discord.ui.button(label="🎴 Rút", style=discord.ButtonStyle.primary)
    async def hit(self, i, b):
        if i.user.id not in self.hands or i.user.id != self.current:
            return await i.response.send_message("❌ Chưa đến lượt!", ephemeral=True)
        self.hands[i.user.id].append(self.draw())
        if self.score(self.hands[i.user.id]) > 21: self.finished[i.user.id] = True; self._next()
        if self._done(): return await self._finish(i)
        await i.response.edit_message(embed=self.make_embed(), view=self)
    @discord.ui.button(label="✋ Dừng", style=discord.ButtonStyle.danger)
    async def stand(self, i, b):
        if i.user.id not in self.hands or i.user.id != self.current:
            return await i.response.send_message("❌ Chưa đến lượt!", ephemeral=True)
        self.finished[i.user.id] = True; self._next()
        if self._done(): return await self._finish(i)
        await i.response.edit_message(embed=self.make_embed(), view=self)
    def _next(self):
        if not self.finished[self.p1.id]: self.current = self.p1.id
        elif not self.finished[self.p2.id]: self.current = self.p2.id
        else: self.current = None
    def _done(self): return all(self.finished.values())
    async def _finish(self, i):
        s1, s2 = self.score(self.hands[self.p1.id]), self.score(self.hands[self.p2.id])
        if s1>21 and s2>21: winner, desc, col = None, "🤝 CẢ 2 QUẮC - HÒA!", "warning"
        elif s1>21 or (s2<=21 and s2>s1): winner, desc, col = self.p2, f"🎉 {self.p2.mention} THẮNG!", "gold"
        elif s2>21 or s1>s2: winner, desc, col = self.p1, f"🎉 {self.p1.mention} THẮNG!", "gold"
        else: winner, desc, col = None, "🤝 HÒA!", "warning"
        if winner:
            loser = self.p2 if winner.id == self.p1.id else self.p1
            uw, d = ensure_user(i.guild_id, winner.id); ul, _ = ensure_user(i.guild_id, loser.id)
            take = min(self.bet, ul["coins"]); uw["coins"] += take; ul["coins"] -= take; save_data(d)
        for p in (self.p1, self.p2): add_quest_progress(i.guild_id, p.id, "game")
        e = E(f"🎴 **{self.p1.display_name}**: `{s1}` điểm\n🎴 **{self.p2.display_name}**: `{s2}` điểm\n\n## {desc}", "🃏 KẾT QUẢ", col)
        self.stop(); await i.response.edit_message(embed=e, view=None)

class MarryView(discord.ui.View):
    def __init__(self, a, b): super().__init__(timeout=60); self.a, self.b = a, b
    @discord.ui.button(label="Đồng ý", style=discord.ButtonStyle.success, emoji="💍")
    async def yes(self, i, b):
        if i.user.id != self.b.id: return await i.response.send_message("❌ Không dành cho bạn!", ephemeral=True)
        ua, d = ensure_user(i.guild_id, self.a.id); ub, _ = ensure_user(i.guild_id, self.b.id)
        if ua.get("married_to") or ub.get("married_to"):
            return await i.response.send_message("❌ Một trong hai đã kết hôn!", ephemeral=True)
        ua["married_to"], ub["married_to"] = self.b.id, self.a.id; save_data(d); self.stop()
        await i.response.edit_message(embed=E(f"💞 {self.a.mention} và {self.b.mention} về chung một nhà!", "💒 CHÚC MỪNG!", "pink"), view=None)
    @discord.ui.button(label="Từ chối", style=discord.ButtonStyle.danger, emoji="💔")
    async def no(self, i, b):
        if i.user.id != self.b.id: return await i.response.send_message("❌ Không dành cho bạn!", ephemeral=True)
        self.stop(); await i.response.edit_message(embed=E(f"{self.b.mention} đã từ chối {self.a.mention}...", "💔 BỊ TỪ CHỐI", "danger"), view=None)

class WerewolfLobby(discord.ui.View):
    def __init__(self, host_id): super().__init__(timeout=120); self.host_id, self.players = host_id, []
    @discord.ui.button(label="Tham gia", style=discord.ButtonStyle.green, emoji="🐺")
    async def join(self, i, b):
        if i.user.id in self.players: return await i.response.send_message("Đã tham gia!", ephemeral=True)
        if len(self.players) >= 12: return await i.response.send_message("Đủ người!", ephemeral=True)
        self.players.append(i.user.id)
        await i.response.send_message(f"✅ Đã vào! ({len(self.players)} người)", ephemeral=True)
    @discord.ui.button(label="Bắt đầu", style=discord.ButtonStyle.danger, emoji="▶️")
    async def start(self, i, b):
        if i.user.id != self.host_id: return await i.response.send_message("Chỉ host!", ephemeral=True)
        if len(self.players) < 4: return await i.response.send_message("Cần ≥4 người!", ephemeral=True)
        if i.guild_id in werewolf_games: return await i.response.send_message("Đang có game!", ephemeral=True)
        self.stop(); await self._assign(i)
    async def _assign(self, i):
        n = len(self.players); wolves = max(1, n // 4)
        roles = ["🐺 Sói"]*wolves + ["👁️ Tiên tri"] + ["🏘️ Dân làng"]*(n - wolves - 1); random.shuffle(roles)
        werewolf_games[i.guild_id] = {"host":self.host_id,"players":self.players,"roles":dict(zip(self.players, roles)),
                                      "alive":set(self.players),"wolf_kill":None,"votes":{}}
        await i.response.send_message(embed=E(f"> **{n}** người chơi · 🐺 **{wolves}** Sói\n> 📩 Gửi vai qua DM...\n\n🌙 **ĐÊM 1** - Sói `/wolf kill`, Tiên tri `/wolf check`", "🐺 MA SÓI BẮT ĐẦU!", "dark"))
        failed = []
        for uid, role in werewolf_games[i.guild_id]["roles"].items():
            m = await fetch_m(i.guild, uid)
            try:
                await m.send(embed=E(f"Vai: **{role}**\n\n> 🐺 Sói: `/wolf kill @user`\n> 👁️ Tiên tri: `/wolf check @user`\n> 🏘️ Dân: `/wolf vote @user` ban ngày", "🐺 VAI CỦA BẠN", "danger"))
            except Exception: failed.append(f"<@{uid}>")
        if failed:
            try: await i.channel.send(f"⚠️ Không DM được cho {' '.join(failed)} — hãy mở DM rồi nhờ host `/wolf end` & tạo lại!")
            except Exception: pass

class JoinRequestView(discord.ui.View):
    def __init__(self, gang_name, requester_id, leader_ids):
        super().__init__(timeout=3600); self.gang_name, self.requester_id, self.leader_ids = gang_name, requester_id, set(leader_ids)
    @discord.ui.button(label="Duyệt", style=discord.ButtonStyle.success, emoji="✅")
    async def accept(self, i, b):
        if i.user.id not in self.leader_ids: return await i.response.send_message("❌ Chỉ chủ/phó!", ephemeral=True)
        _, gang = find_gang(i.guild_id, self.gang_name)
        if not gang: return await i.response.send_message("❌ Bang không tồn tại!", ephemeral=True)
        if is_gang_member(gang, self.requester_id): return await i.response.send_message("⚠️ Đã trong bang!", ephemeral=True)
        u, d = ensure_user(i.guild_id, self.requester_id)
        if u.get("gang"): return await i.response.send_message("⚠️ Người này đã vào bang khác!", ephemeral=True)
        gang.setdefault("members", []).append(self.requester_id)
        await gang_channel_add(i.guild, gang, self.requester_id)
        u["gang"] = gang["name"]; save_user(i.guild_id, self.requester_id, u, d)
        self.stop(); await i.response.edit_message(embed=E(f"> <@{self.requester_id}> đã được duyệt bởi {i.user.mention}\n> 🏯 Bang: **{gang['name']}**", "✅ ĐÃ DUYỆT", "success"), view=None)
    @discord.ui.button(label="Từ chối", style=discord.ButtonStyle.danger, emoji="❌")
    async def reject(self, i, b):
        if i.user.id not in self.leader_ids: return await i.response.send_message("❌ Chỉ chủ/phó!", ephemeral=True)
        self.stop(); await i.response.edit_message(embed=E(f"> <@{self.requester_id}> bị từ chối bởi {i.user.mention}", "❌ ĐÃ TỪ CHỐI", "danger"), view=None)

# ============================================================
# 🤖 BOT INIT
# ============================================================
intents = discord.Intents.none()
intents.guilds = True; intents.guild_messages = True; intents.message_content = True; intents.members = True

class LiteBot(discord.Client):
    def __init__(self):
        super().__init__(intents=intents, max_messages=None,
                         member_cache_flags=discord.MemberCacheFlags.none(),
                         chunk_guilds_at_startup=False)
        self.tree = app_commands.CommandTree(self)
        self.web_loop = None; self.started = time.time(); self._web_started = False
    async def setup_hook(self):
        self.web_loop = asyncio.get_running_loop()
        self.add_view(CatView())
        try:
            synced = await self.tree.sync(); print(f"✅ Synced {len(synced)} top-level commands.")
        except Exception as e: print(f"⚠️ Sync error: {e}")
        for t in (autosave, hourly_boss, memory_cleanup, web_notif_task): t.start()
        if KEEPALIVE_URL: keepalive.start()
        if not self._web_started: self._web_started = True; start_web()

bot = LiteBot()
active_bosses, active_guesses, active_auctions, werewolf_games = {}, {}, {}, {}
_bg_tasks = set()   # giữ tham chiếu task nền (tránh bị GC)

@bot.tree.error
async def on_tree_error(i, error):
    print("⚠️ Command error:", repr(error))
    traceback.print_exception(type(error), error, error.__traceback__)
    try:
        msg = "❌ Có lỗi xảy ra, thử lại sau nhé!"
        if i.response.is_done(): await i.followup.send(msg, ephemeral=True)
        else: await i.response.send_message(msg, ephemeral=True)
    except Exception: pass

# ============================================================
# ⏰ TASKS
# ============================================================
@tasks.loop(seconds=20)
async def autosave(): flush_data()

@tasks.loop(hours=2)
async def hourly_boss():
    if hourly_boss.current_loop == 0: return            # không spawn boss mỗi lần restart bot
    data = load_data()
    for gid, ch_id in list(data.get("boss_channels", {}).items()):
        if gid in active_bosses: continue
        guild = bot.get_guild(int(gid)); ch = guild.get_channel(ch_id) if guild else None
        if not ch: continue
        view = BossView(random.choice(BOSS_NAMES), random.randint(5000, 15000), gid)
        active_bosses[gid] = view
        try: await ch.send(embed=view.make_embed(), view=view)
        except Exception: active_bosses.pop(gid, None)

KEEPALIVE_URL = (os.environ.get("KEEPALIVE_URL") or os.environ.get("RENDER_EXTERNAL_URL") or "").strip().rstrip("/")

@tasks.loop(minutes=9)
async def keepalive():
    """Render free ngủ sau 15 phút không có truy cập -> tự gọi /ping của chính mình qua link công khai."""
    def hit():
        import urllib.request
        try: urllib.request.urlopen(urllib.request.Request(KEEPALIVE_URL + "/ping", headers={"User-Agent": "keepalive"}), timeout=20).read()
        except Exception as e: print("keepalive lỗi:", e)
    await asyncio.to_thread(hit)

@tasks.loop(minutes=10)
async def memory_cleanup():
    now = time.time()
    for k in [k for k, h in mod_history.items() if not h or now - h[-1][0] > 60]: mod_history.pop(k, None)
    for k in list(warn_tracker.keys()):
        if now - warn_tracker[k].get("last", 0) > 3600: del warn_tracker[k]
    data = load_data(); t = today()
    for gid in list(data.get("wordle", {}).keys()):
        if data["wordle"][gid].get("date") != t:
            del data["wordle"][gid]; save_data()
    gc.collect()

_owner_cache = None
async def get_owner():
    global _owner_cache
    if _owner_cache: return _owner_cache
    try:
        if OWNER_ID: _owner_cache = bot.get_user(OWNER_ID) or await bot.fetch_user(OWNER_ID)
        else: _owner_cache = (await bot.application_info()).owner
    except Exception as e: print("⚠️ Không lấy được owner:", e)
    return _owner_cache

@tasks.loop(seconds=20)
async def web_notif_task():
    """Gửi DM cho owner (và người trúng) khi có ticket trúng acc từ web."""
    data = load_data(); q = data.get("notif_queue")
    if not q: return
    owner = await get_owner()
    for tid in list(q):
        t = next((x for x in data.get("tickets", []) if x["ticket"] == tid), None)
        if not t: q.remove(tid); save_data(); continue
        if owner:
            try:
                await owner.send(f"🎉 **TRÚNG THƯỞNG VÒNG QUAY**\n> User: <@{t['discord_id']}> (`{t['username']}`)\n"
                                 f"> Server: **{t['guild_name']}**\n> Giải: **{t['prize']}**\n> Mã: `{t['code']}`\n"
                                 f"> Ticket: `{t['ticket']}`\n> Thời gian: {t['time']}\n\n"
                                 f"⚠️ Liên hệ user qua: {SUPPORT_INVITE}\nXong dùng `/web done {t['ticket']}`")
            except Exception as e:
                print("notif owner error:", e); break          # thử lại ở vòng sau
        q.remove(tid); save_data()
        try:                                                    # báo cho người trúng (nếu DM mở)
            u = bot.get_user(t["discord_id"]) or await bot.fetch_user(t["discord_id"])
            await u.send(f"🎉 Bạn trúng **{t['prize']}** ở vòng quay!\n> Ticket: `{t['ticket']}`\n> Vào {SUPPORT_INVITE} và đưa mã ticket cho chủ server để nhận.")
        except Exception: pass

# ============================================================
# 🎬 EVENTS
# ============================================================
_ready_done = False

@bot.event
async def on_ready():
    global _ready_done
    print(f"🤖 Bot ready: {bot.user}")
    await bot.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name=f"✨ {CURRENCY} · /help"))
    if not _ready_done:
        _ready_done = True
        for g in bot.guilds: await ensure_guild_invite(g)

@bot.event
async def on_guild_join(guild): await ensure_guild_invite(guild)

@bot.event
async def on_message(message):
    if message.author.bot or not message.guild: return
    content = message.content.strip(); gid, uid = message.guild.id, message.author.id

    # Tự cấp tài khoản web (lười: người cũ lẫn mới đều nhận khi nhắn tin lần đầu)
    acc, pw = ensure_web_account(gid, uid, message.author.display_name)
    if pw:
        try: await message.author.send(embed=cred_embed(acc, pw))
        except Exception:
            try: await message.channel.send(f"🌐 {message.author.mention} bot không DM được — dùng `/web login` để lấy tài khoản web nhé!", delete_after=15)
            except Exception: pass

    g = active_guesses.get(message.channel.id)
    if g and g.get("active") and content.upper() == g["answer"]:
        g["active"] = False; active_guesses.pop(message.channel.id, None)
        new_bal = add_coins(gid, uid, 200); data = load_data()
        gs = data.setdefault("guess_scores", {}).setdefault(str(gid), {})
        gs[str(uid)] = gs.get(str(uid), 0) + 1; save_data(data)
        return await message.reply(embed=E(f"> {message.author.mention} đoán đúng!\n> Đáp án: **{g['answer']}**\n> 🏆 `+200` {CURRENCY}\n> 💰 Số dư: `{new_bal:,}`", "🎉 CHÍNH XÁC!", "gold"))

    if content == "?": return await message.reply("? 🤨")

    u, d = ensure_user(gid, uid)

    if u.get("afk"):
        u["afk"] = None; save_data(d)
        try: await message.channel.send(f"👋 Chào mừng {message.author.mention} đã trở lại!", delete_after=5)
        except Exception: pass
    if message.mentions:
        users = d.get("users", {}).get(str(gid), {})
        for m in message.mentions[:5]:
            mu = users.get(str(m.id))
            if mu and mu.get("afk"):
                try: await message.reply(f"💤 **{m.display_name}** đang bận: *{mu['afk']}*", mention_author=False)
                except Exception: pass

    if not message.author.guild_permissions.administrator:
        is_spam, spam_reason = check_spam(message)
        if is_spam: return await punish_user(message, 100, [f"Spam: {spam_reason}"], spam_reason)
        score, reasons = analyze_content(content)
        if score >= 40: return await punish_user(message, score, reasons)

    now = int(time.time())
    if now - u.get("last_msg_xp", 0) >= 60:
        u["last_msg_xp"] = now; u["xp"] += random.randint(5, 15)
        u["stats"]["chat"] = u["stats"].get("chat", 0) + 1
        add_quest_progress(gid, uid, "chat")
        leveled = False
        while u["xp"] >= xp_need(u["level"]):
            u["xp"] -= xp_need(u["level"]); u["level"] += 1; u["coins"] += u["level"]*20; leveled = True
            if u["level"] == 10:
                ach = unlock_achievement(gid, uid, "level_10")
                if ach:
                    try: await message.channel.send(embed=ach)
                    except Exception: pass
        save_data(d)
        if leveled:
            e = E(f"> Chúc mừng {message.author.mention} đạt **Level {u['level']}**!\n> {CURRENCY}: `+{u['level']*20}`", "🎊 THĂNG CẤP!", "gold")
            e.set_thumbnail(url=message.author.display_avatar.url)
            try: await message.channel.send(embed=e, delete_after=15)
            except Exception: pass

@bot.event
async def on_member_join(member):
    if member.bot: return
    acc, pw = ensure_web_account(member.guild.id, member.id, member.display_name)
    if pw:
        try: await member.send(embed=cred_embed(acc, pw, f"🎁 CHÀO MỪNG ĐẾN {member.guild.name.upper()}"))
        except Exception: pass
    w = load_data().get("welcome", {}).get(str(member.guild.id))
    if not w: return
    ch = member.guild.get_channel(w.get("channel_id"))
    if not ch: return
    msg = w.get("message", "Chào mừng {user} đến với {guild}!").replace("{user}", member.mention).replace("{guild}", member.guild.name)
    e = E(f"> {msg}", "👋 CHÀO MỪNG THÀNH VIÊN MỚI!", "success")
    e.timestamp = datetime.datetime.now(timezone.utc)
    e.set_thumbnail(url=member.display_avatar.url)
    e.add_field(name="👤 Thành viên", value=member.mention, inline=True)
    e.add_field(name="📅 Tạo TK", value=member.created_at.strftime("%d/%m/%Y"), inline=True)
    e.add_field(name="👥 Tổng", value=f"#{member.guild.member_count}", inline=True)
    try: await ch.send(embed=e)
    except Exception: pass

# ============================================================
# 🎮 STANDALONE COMMANDS
# ============================================================
def G(name, desc, **kw):
    g = app_commands.Group(name=name, description=desc, guild_only=True, **kw)
    bot.tree.add_command(g); return g

@bot.tree.command(name="ping", description="🏓 Kiểm tra độ trễ")
async def ping(i: discord.Interaction):
    await i.response.send_message(embed=E(f"📡 `{round(bot.latency*1000)}ms`\n🟢 **Online**", "🏓 Pong!", "success"))

@bot.tree.command(name="help", description="📖 Danh sách nhóm lệnh")
async def help_cmd(i: discord.Interaction):
    total, e = 2, E("> Gõ `/nhóm lệnh` để dùng · `/web help` để xem hướng dẫn web\n> Chung: `/ping` · `/help`\n\u200b", "📖 TRUNG TÂM HỖ TRỢ", "cyan")
    for c in bot.tree.get_commands():
        if isinstance(c, app_commands.Group):
            subs = [s.name for s in c.commands]; total += len(subs)
            e.add_field(name=f"`/{c.name}` — {c.description}", value=" · ".join(subs)[:1000], inline=False)
    e.set_footer(text=f"{total} lệnh · {CURRENCY}", icon_url=bot.user.display_avatar.url)
    await i.response.send_message(embed=e)

# ============================================================
# 🛡️ ADMIN GROUP
# ============================================================
admin_g = G("admin", "🛡️ Lệnh quản trị")

def _can_mod(i, target):
    if i.user.id == target.id: return False, "❌ Không thể tự xử lý chính mình!"
    if target.top_role >= i.user.top_role and i.guild.owner_id != i.user.id:
        return False, "❌ Không thể xử lý người có role cao hơn/ngang!"
    return True, ""

@admin_g.command(name="kick", description="👢 Kick thành viên")
async def admin_kick(i: discord.Interaction, member: discord.Member, reason: str = "Không có lý do"):
    if not i.user.guild_permissions.kick_members: return await i.response.send_message("❌ Không có quyền!", ephemeral=True)
    ok, msg = _can_mod(i, member)
    if not ok: return await i.response.send_message(msg, ephemeral=True)
    try:
        await member.kick(reason=reason)
        await i.response.send_message(embed=E(f"> {member.mention}\n> **Lý do:** {reason}", "👢 ĐÃ KICK", "danger"))
    except Exception as e: await i.response.send_message(f"❌ Lỗi: {e}", ephemeral=True)

@admin_g.command(name="ban", description="🔨 Ban thành viên")
async def admin_ban(i: discord.Interaction, member: discord.Member, reason: str = "Không có lý do"):
    if not i.user.guild_permissions.ban_members: return await i.response.send_message("❌ Không có quyền!", ephemeral=True)
    ok, msg = _can_mod(i, member)
    if not ok: return await i.response.send_message(msg, ephemeral=True)
    try:
        await member.ban(reason=reason)
        await i.response.send_message(embed=E(f"> {member.mention}\n> **Lý do:** {reason}", "🔨 ĐÃ BAN", "danger"))
    except Exception as e: await i.response.send_message(f"❌ Lỗi: {e}", ephemeral=True)

@admin_g.command(name="unban", description="🔓 Gỡ ban bằng ID")
async def admin_unban(i: discord.Interaction, user_id: str):
    if not i.user.guild_permissions.ban_members: return await i.response.send_message("❌ Không có quyền!", ephemeral=True)
    if not user_id.isdigit(): return await i.response.send_message("❌ ID phải là số!", ephemeral=True)
    try:
        await i.guild.unban(discord.Object(id=int(user_id)))
        await i.response.send_message(embed=E(f"> Đã gỡ ban <@{user_id}>", "🔓 THÀNH CÔNG", "success"))
    except discord.NotFound: await i.response.send_message("❌ Không bị ban!", ephemeral=True)
    except Exception as e: await i.response.send_message(f"❌ Lỗi: {e}", ephemeral=True)

@admin_g.command(name="timeout", description="🔇 Timeout thành viên")
async def admin_timeout(i: discord.Interaction, member: discord.Member,
                        minutes: app_commands.Range[int,1,40320] = 10, reason: str = "Vi phạm"):
    if not i.user.guild_permissions.moderate_members: return await i.response.send_message("❌ Không có quyền!", ephemeral=True)
    ok, msg = _can_mod(i, member)
    if not ok: return await i.response.send_message(msg, ephemeral=True)
    try:
        await member.timeout(timedelta(minutes=minutes), reason=reason)
        await i.response.send_message(embed=E(f"> {member.mention} — `{minutes} phút`\n> **Lý do:** {reason}", "🔇 ĐÃ TIMEOUT", "warning"))
    except Exception as e: await i.response.send_message(f"❌ Lỗi: {e}", ephemeral=True)

@admin_g.command(name="untimeout", description="🔊 Gỡ timeout")
async def admin_untimeout(i: discord.Interaction, member: discord.Member):
    if not i.user.guild_permissions.moderate_members: return await i.response.send_message("❌ Không có quyền!", ephemeral=True)
    try:
        await member.timeout(None)
        await i.response.send_message(embed=E(f"> {member.mention} đã được gỡ.", "🔊 THÀNH CÔNG", "success"))
    except Exception as e: await i.response.send_message(f"❌ Lỗi: {e}", ephemeral=True)

@admin_g.command(name="warn", description="⚠️ Cảnh cáo thành viên")
async def admin_warn(i: discord.Interaction, member: discord.Member, reason: str = "Vi phạm"):
    if not i.user.guild_permissions.moderate_members: return await i.response.send_message("❌ Không có quyền!", ephemeral=True)
    data = load_data()
    warns = data.setdefault("warns", {}).setdefault(str(i.guild_id), {}).setdefault(str(member.id), [])
    warns.append({"by": i.user.id, "reason": reason[:200], "ts": int(time.time())}); save_data(data)
    await i.response.send_message(embed=E(f"> {member.mention}\n> **Lý do:** {reason}\n> **Tổng:** `{len(warns)}`", "⚠️ ĐÃ CẢNH CÁO", "warning"))

@admin_g.command(name="clearwarns", description="🧽 Xóa cảnh cáo")
async def admin_clearwarns(i: discord.Interaction, member: discord.Member):
    if not i.user.guild_permissions.moderate_members: return await i.response.send_message("❌ Không có quyền!", ephemeral=True)
    data = load_data(); w = data.get("warns", {}).get(str(i.guild_id), {}); n = len(w.pop(str(member.id), []))
    save_data(data)
    await i.response.send_message(embed=E(f"> Đã xóa `{n}` cảnh cáo của {member.mention}", "🧽 XONG", "success"))

@admin_g.command(name="modlog", description="📋 Lịch sử cảnh cáo")
async def admin_modlog(i: discord.Interaction, member: discord.Member):
    warns = load_data().get("warns", {}).get(str(i.guild_id), {}).get(str(member.id), [])
    if not warns: return await i.response.send_message(f"✅ {member.mention} không có cảnh cáo!", ephemeral=True)
    e = E(color="warning", title=f"📋 {member.display_name}")
    for k, w in enumerate(warns[-10:], 1):
        e.add_field(name=f"#{k} · <t:{w['ts']}:R>", value=f"> Bởi: <@{w['by']}>\n> {w['reason']}", inline=False)
    await i.response.send_message(embed=e)

@admin_g.command(name="clear", description="🧹 Xóa tin nhắn (1-100)")
async def admin_clear(i: discord.Interaction, amount: app_commands.Range[int,1,100]):
    if not i.user.guild_permissions.manage_messages: return await i.response.send_message("❌ Không có quyền!", ephemeral=True)
    await i.response.defer(ephemeral=True)
    try:
        deleted = await i.channel.purge(limit=amount)
        await i.followup.send(f"🧹 Đã xóa `{len(deleted)}` tin nhắn!", ephemeral=True)
    except Exception as e: await i.followup.send(f"❌ Lỗi: {e}", ephemeral=True)

@admin_g.command(name="slowmode", description="🐢 Slowmode (0 = tắt)")
async def admin_slowmode(i: discord.Interaction, seconds: app_commands.Range[int,0,21600]):
    if not i.user.guild_permissions.manage_channels: return await i.response.send_message("❌ Không có quyền!", ephemeral=True)
    try:
        await i.channel.edit(slowmode_delay=seconds)
        await i.response.send_message(embed=E("🐢 Đã tắt slowmode." if seconds == 0 else f"🐢 `{seconds}s`", color="info"))
    except Exception as e: await i.response.send_message(f"❌ Lỗi: {e}", ephemeral=True)

@admin_g.command(name="lock", description="🔒 Khóa kênh")
async def admin_lock(i: discord.Interaction):
    if not i.user.guild_permissions.manage_channels: return await i.response.send_message("❌ Không có quyền!", ephemeral=True)
    try:
        ow = i.channel.overwrites_for(i.guild.default_role); ow.send_messages = False
        await i.channel.set_permissions(i.guild.default_role, overwrite=ow)
        await i.response.send_message(embed=E("🔒 Kênh đã **khóa**.", color="warning"))
    except Exception as e: await i.response.send_message(f"❌ Lỗi: {e}", ephemeral=True)

@admin_g.command(name="unlock", description="🔓 Mở khóa kênh")
async def admin_unlock(i: discord.Interaction):
    if not i.user.guild_permissions.manage_channels: return await i.response.send_message("❌ Không có quyền!", ephemeral=True)
    try:
        ow = i.channel.overwrites_for(i.guild.default_role); ow.send_messages = None
        await i.channel.set_permissions(i.guild.default_role, overwrite=ow)
        await i.response.send_message(embed=E("🔓 Kênh đã **mở khóa**.", color="success"))
    except Exception as e: await i.response.send_message(f"❌ Lỗi: {e}", ephemeral=True)

# ============================================================
# ⚙️ SETUP GROUP (chỉ admin thấy)
# ============================================================
setup_g = G("setup", "⚙️ Cấu hình server (Admin)", default_permissions=discord.Permissions(administrator=True))

@setup_g.command(name="setwelcome", description="👋 Cài kênh chào mừng")
async def setup_setwelcome(i: discord.Interaction, channel: discord.TextChannel, message: str = "Chào mừng {user} đến với {guild}!"):
    if not is_admin(i): return await i.response.send_message("❌ Chỉ admin!", ephemeral=True)
    data = load_data(); data.setdefault("welcome", {})[str(i.guild_id)] = {"channel_id": channel.id, "message": message[:300]}
    save_data(data)
    await i.response.send_message(embed=E(f"> Kênh: {channel.mention}\n> Nội dung: {message[:300]}", "✅ ĐÃ CÀI", "success"), ephemeral=True)

@setup_g.command(name="bosssetup", description="⚔️ Spawn World Boss + tự động mỗi 2h")
async def setup_bosssetup(i: discord.Interaction, hp: app_commands.Range[int,500,100000] = 10000):
    if not is_admin(i): return await i.response.send_message("❌ Chỉ admin!", ephemeral=True)
    data = load_data(); data.setdefault("boss_channels", {})[str(i.guild_id)] = i.channel_id; save_data(data)
    gid = str(i.guild_id); view = BossView(random.choice(BOSS_NAMES), hp, gid); active_bosses[gid] = view
    await i.response.send_message("✅ Spawn boss + tự động mỗi 2h!", ephemeral=True)
    await i.channel.send(embed=view.make_embed(), view=view)

@setup_g.command(name="grantrole", description="👑 Cấp role đặc biệt")
@app_commands.choices(role=[
    app_commands.Choice(name="💖 amaterasu", value=SPECIAL_ROLE_AMATERASU),
    app_commands.Choice(name="🤑 yamate kudashi", value=SPECIAL_ROLE_YAMATE),
    app_commands.Choice(name="🌙 tsukuyomi", value=SPECIAL_ROLE_TSUKUYOMI),
    app_commands.Choice(name="⚡ susanoo", value=SPECIAL_ROLE_SUSANOO),
    app_commands.Choice(name="💀 izanami", value=SPECIAL_ROLE_IZANAMI),
])
async def setup_grantrole(i: discord.Interaction, member: discord.Member, role: app_commands.Choice[str]):
    if not is_admin(i): return await i.response.send_message("❌ Chỉ admin!", ephemeral=True)
    r = discord.utils.get(i.guild.roles, name=role.value)
    if not r: return await i.response.send_message(f"❌ Role **{role.value}** chưa tồn tại!", ephemeral=True)
    try:
        await member.add_roles(r)
        await i.response.send_message(embed=E(f"✅ Đã cấp **{role.value}** cho {member.mention}", color="success"), ephemeral=True)
    except Exception as e: await i.response.send_message(f"❌ Lỗi: {e}", ephemeral=True)

@setup_g.command(name="meonow", description="🐱 Tạo khu mèo (1 kênh/server)")
async def setup_meonow(i: discord.Interaction):
    if not is_admin(i): return await i.response.send_message("❌ Chỉ admin!", ephemeral=True)
    data = load_data(); cc = data.setdefault("cats", {}); gid = str(i.guild_id)
    if gid in cc and cc[gid].get("channel_id"):
        old_ch = i.guild.get_channel(cc[gid]["channel_id"])
        if old_ch: return await i.response.send_message(embed=E(f"> Server đã có khu mèo tại {old_ch.mention}!", "❌ LỖI", "danger"), ephemeral=True)
    cc[gid] = {"channel_id": i.channel_id, "cats": cc.get(gid, {}).get("cats", {})}; save_data(data)
    e = E("> Bấm nút bên dưới!\n> **Mỗi người có 1 con mèo riêng** 🎉", "🐾 KHU MÈO ĐÃ MỞ!", "pink")
    e.add_field(name="🍖 Cho ăn", value="+No +XP", inline=True)
    e.add_field(name="🎾 Chơi", value="+Vui +XP", inline=True)
    e.add_field(name="🤚 Vuốt", value="+Streak +Coin", inline=True)
    e.add_field(name="👀 Xem", value="Xem info", inline=True)
    await i.response.send_message("✅ Đã tạo khu mèo!", ephemeral=True)
    await i.channel.send(embed=e, view=CatView())

@setup_g.command(name="webinfo", description="🌐 Đặt tên chính & link vào server (hiện trên web admin)")
async def setup_webinfo(i: discord.Interaction, name: str = None, url: str = None):
    if not is_admin(i): return await i.response.send_message("❌ Chỉ admin!", ephemeral=True)
    m = gmeta(i.guild_id)
    if name is not None: m["alias"] = name.strip()[:40]
    if url is not None:
        if url and not re.match(r"^https?://", url): return await i.response.send_message("❌ URL phải bắt đầu bằng http(s)://", ephemeral=True)
        m["url"] = url.strip()[:200]
    save_data()
    await i.response.send_message(embed=E(f"> 🏷️ Tên chính: **{m.get('alias') or '*chưa đặt*'}**\n> 🔗 URL: {m.get('url') or '*chưa có*'}", "🌐 THÔNG TIN WEB", "success"), ephemeral=True)

# ============================================================
# 🔧 UTILITY GROUP
# ============================================================
util_g = G("utility", "🔧 Tiện ích")

@util_g.command(name="avatar", description="🖼️ Avatar thành viên")
async def util_avatar(i: discord.Interaction, member: discord.Member = None):
    t = member or i.user
    e = E(f"[Tải ảnh]({t.display_avatar.url})", f"🖼️ {t.display_name.upper()}", "purple")
    e.set_image(url=t.display_avatar.url)
    await i.response.send_message(embed=e)

@util_g.command(name="userinfo", description="👤 Thông tin thành viên")
async def util_userinfo(i: discord.Interaction, member: discord.Member = None):
    t = member or i.user
    roles = " ".join(r.mention for r in list(reversed(t.roles))[:-1][:10]) or "*Không có*"
    e = E(color="cyan", title=f"👤 {t.display_name}")
    e.set_thumbnail(url=t.display_avatar.url)
    e.add_field(name="🆔 ID", value=f"`{t.id}`", inline=True)
    e.add_field(name="📅 Tạo", value=f"<t:{int(t.created_at.timestamp())}:D>", inline=True)
    e.add_field(name="📥 Vào", value=f"<t:{int(t.joined_at.timestamp())}:D>" if t.joined_at else "?", inline=True)
    e.add_field(name="🎭 Roles", value=roles, inline=False)
    await i.response.send_message(embed=e)

@util_g.command(name="serverinfo", description="🏠 Thông tin server")
async def util_serverinfo(i: discord.Interaction):
    g = i.guild
    e = E(color="cyan", title=f"🏠 {g.name}")
    if g.icon: e.set_thumbnail(url=g.icon.url)
    e.add_field(name="👑", value=f"<@{g.owner_id}>", inline=True)
    e.add_field(name="👥", value=f"`{g.member_count}`", inline=True)
    e.add_field(name="📅", value=f"<t:{int(g.created_at.timestamp())}:D>", inline=True)
    e.add_field(name="💬", value=f"`{len(g.text_channels)}`", inline=True)
    e.add_field(name="🔊", value=f"`{len(g.voice_channels)}`", inline=True)
    e.add_field(name="💎", value=f"`{g.premium_subscription_count}` (Lv{g.premium_tier})", inline=True)
    await i.response.send_message(embed=e)

@util_g.command(name="afk", description="💤 Treo máy")
async def util_afk(i: discord.Interaction, reason: str = "Không có lý do"):
    u, d = ensure_user(i.guild_id, i.user.id); u["afk"] = reason[:100]; save_user(i.guild_id, i.user.id, u, d)
    await i.response.send_message(embed=E(f"💤 AFK: **{reason[:100]}**"), ephemeral=True)

# ============================================================
# 💰 ECO GROUP
# ============================================================
eco_g = G("eco", f"💰 Kinh tế {CURRENCY}")

def cooldown_check(u, key, cd):
    now = int(time.time())
    if now - u.get(key, 0) < cd: return False, f"⏰ Chờ `{cd - (now - u[key])}s`!"
    u[key] = now; return True, ""

@eco_g.command(name="daily", description="🎁 Điểm danh hàng ngày")
async def eco_daily(i: discord.Interaction):
    u, d = ensure_user(i.guild_id, i.user.id); t = today()
    if u.get("last_daily") == t:
        return await i.response.send_message(embed=E("Mai quay lại nhé!", "⏰ ĐÃ ĐIỂM DANH", "warning"), ephemeral=True)
    reward = random.randint(100, 500); u["coins"] += reward; u["last_daily"] = t; save_user(i.guild_id, i.user.id, u, d)
    e = E(f"> Nhận được: `+{reward}` {CURRENCY}\n> 💰 Tổng: `{u['coins']:,}`", "🎁 ĐIỂM DANH!", "gold")
    e.set_thumbnail(url=i.user.display_avatar.url)
    await i.response.send_message(embed=e)
    ach = unlock_achievement(i.guild_id, i.user.id, "first_daily")
    if ach: await i.channel.send(embed=ach)
    if u["coins"] >= 10000:
        ach = unlock_achievement(i.guild_id, i.user.id, "rich_10k")
        if ach: await i.channel.send(embed=ach)

@eco_g.command(name="work", description="💼 Làm việc kiếm coin (1h)")
async def eco_work(i: discord.Interaction):
    u, d = ensure_user(i.guild_id, i.user.id); now = int(time.time())
    if now - u.get("last_work", 0) < 3600:
        return await i.response.send_message(embed=E(f"Quay lại sau `{3600 - (now - u['last_work'])}s`!", "⏰ ĐANG MỆT!", "warning"), ephemeral=True)
    job = random.choice(["Lập trình viên 💻","Đầu bếp 🍳","Bác sĩ 🩺","Giáo viên 📚","Ca sĩ 🎤","Nông dân 🌾"])
    reward = random.randint(50, 250); u["coins"] += reward; u["last_work"] = now
    u["stats"]["work"] = u["stats"].get("work", 0) + 1; save_user(i.guild_id, i.user.id, u, d)
    add_quest_progress(i.guild_id, i.user.id, "work")
    e = E(f"> Bạn làm **{job}** → `+{reward}` {CURRENCY}\n> 💰 Tổng: `{u['coins']:,}`", "💼 XONG!", "info")
    e.set_thumbnail(url=i.user.display_avatar.url)
    await i.response.send_message(embed=e)

@eco_g.command(name="balance", description="💰 Xem số dư")
async def eco_balance(i: discord.Interaction, member: discord.Member = None):
    t = member or i.user; u, _ = ensure_user(i.guild_id, t.id)
    e = E(title=f"💳 {t.display_name.upper()}", color="gold")
    e.add_field(name="👛 Ví", value=f"`{u.get('coins',0):,}` {CURRENCY}", inline=True)
    e.add_field(name="🏦 Bank", value=f"`{u.get('bank',0):,}` {CURRENCY}", inline=True)
    e.add_field(name="💵 Tổng", value=f"**`{u.get('coins',0)+u.get('bank',0):,}`**", inline=False)
    e.set_thumbnail(url=t.display_avatar.url)
    await i.response.send_message(embed=e)

@eco_g.command(name="pay", description="💸 Chuyển coin")
async def eco_pay(i: discord.Interaction, member: discord.Member, amount: int):
    if member.bot or member.id == i.user.id or amount <= 0:
        return await i.response.send_message("❌ Không hợp lệ!", ephemeral=True)
    u, d = ensure_user(i.guild_id, i.user.id); r, _ = ensure_user(i.guild_id, member.id)
    if u.get("coins", 0) < amount: return await i.response.send_message("❌ Không đủ coin!", ephemeral=True)
    u["coins"] -= amount; r["coins"] = r.get("coins", 0) + amount; save_data(d)
    await i.response.send_message(embed=E(f"> {i.user.mention} ➡️ {member.mention}\n> 💵 `{amount:,}` {CURRENCY}", "💸 THÀNH CÔNG", "success"))

@eco_g.command(name="deposit", description="🏦 Gửi coin")
async def eco_deposit(i: discord.Interaction, amount: int):
    if amount <= 0: return await i.response.send_message("❌ > 0!", ephemeral=True)
    u, d = ensure_user(i.guild_id, i.user.id)
    if u.get("coins", 0) < amount: return await i.response.send_message("❌ Ví không đủ!", ephemeral=True)
    u["coins"] -= amount; u["bank"] = u.get("bank", 0) + amount; save_user(i.guild_id, i.user.id, u, d)
    await i.response.send_message(embed=E(f"🏦 Gửi `{amount:,}`\n> 💰 Bank: `{u['bank']:,}`", color="success"), ephemeral=True)

@eco_g.command(name="withdraw", description="🏦 Rút coin")
async def eco_withdraw(i: discord.Interaction, amount: int):
    if amount <= 0: return await i.response.send_message("❌ > 0!", ephemeral=True)
    u, d = ensure_user(i.guild_id, i.user.id)
    if u.get("bank", 0) < amount: return await i.response.send_message("❌ Bank không đủ!", ephemeral=True)
    u["bank"] -= amount; u["coins"] = u.get("coins", 0) + amount; save_user(i.guild_id, i.user.id, u, d)
    await i.response.send_message(embed=E(f"🏦 Rút `{amount:,}`\n> 👛 Ví: `{u['coins']:,}`", color="success"), ephemeral=True)

@eco_g.command(name="rob", description="🥷 Cướp (rủi ro)")
async def eco_rob(i: discord.Interaction, member: discord.Member):
    if member.bot or member.id == i.user.id: return await i.response.send_message("❌ Không hợp lệ!", ephemeral=True)
    u, d = ensure_user(i.guild_id, i.user.id); t, _ = ensure_user(i.guild_id, member.id)
    now = int(time.time())
    if now - u.get("last_rob", 0) < 3600:
        return await i.response.send_message(f"⏰ Chờ `{3600-(now-u['last_rob'])}s`!", ephemeral=True)
    if t.get("coins", 0) < 100: return await i.response.send_message("❌ Nạn nhân quá nghèo!", ephemeral=True)
    u["last_rob"] = now; success = random.random() < 0.4
    if success:
        hi = max(1, int(t["coins"]*0.3)); amount = random.randint(min(50, hi), hi)
        u["coins"] += amount; t["coins"] -= amount
        msg = f"🥷 Cướp được `{amount:,}` từ {member.mention}!"
    else:
        fine = min(u.get("coins", 0), random.randint(50, 200)); u["coins"] -= fine
        msg = f"🚓 Bị bắt! Phạt `{fine:,}`."
    save_data(d)
    await i.response.send_message(embed=E(msg, color="success" if success else "danger"))
    if success:
        ach = unlock_achievement(i.guild_id, i.user.id, "robber")
        if ach: await i.channel.send(embed=ach)

@eco_g.command(name="top", description="🏆 Top 10 đại gia")
async def eco_top(i: discord.Interaction):
    users = load_data().get("users", {}).get(str(i.guild_id), {})
    if not users: return await i.response.send_message("Chưa có dữ liệu!", ephemeral=True)
    top10 = sorted(users.items(), key=lambda x: -(x[1].get("coins",0)+x[1].get("bank",0)))[:10]
    lines = [f"{medal(k)} <@{uid}> — `{u.get('coins',0)+u.get('bank',0):,}` {CURRENCY} · Lv.{u.get('level',1)}" for k, (uid, u) in enumerate(top10)]
    await i.response.send_message(embed=E("\n".join(lines), "🏆 TOP ĐẠI GIA", "gold"))

# ============================================================
# 🎣 ACT GROUP
# ============================================================
act_g = G("act", "🎣 Hoạt động")

@act_g.command(name="fish", description="🎣 Câu cá (60s)")
async def act_fish(i: discord.Interaction):
    u, d = ensure_user(i.guild_id, i.user.id); ok, msg = cooldown_check(u, "last_fish", 60)
    if not ok: return await i.response.send_message(msg, ephemeral=True)
    item, val = random.choice(FISH_POOL)
    u["coins"] += val; u["stats"]["fish"] = u["stats"].get("fish", 0) + 1; save_user(i.guild_id, i.user.id, u, d)
    add_quest_progress(i.guild_id, i.user.id, "fish")
    await i.response.send_message(embed=E(f"> Câu được **{item}**!\n> 💰 `+{val}` {CURRENCY}", "🎣 CÂU CÁ", "info"))
    if u["stats"]["fish"] >= 10:
        ach = unlock_achievement(i.guild_id, i.user.id, "fish_10")
        if ach: await i.channel.send(embed=ach)

@act_g.command(name="mine", description="⛏️ Đào mỏ (60s)")
async def act_mine(i: discord.Interaction):
    u, d = ensure_user(i.guild_id, i.user.id); ok, msg = cooldown_check(u, "last_mine", 60)
    if not ok: return await i.response.send_message(msg, ephemeral=True)
    item, val = random.choice(MINE_POOL)
    u["coins"] += val; u["stats"]["mine"] = u["stats"].get("mine", 0) + 1; save_user(i.guild_id, i.user.id, u, d)
    await i.response.send_message(embed=E(f"> Đào được **{item}**!\n> 💰 `+{val}` {CURRENCY}", "⛏️ HẦM MỎ", "warning"))

@act_g.command(name="hunt", description="🏹 Săn thú (60s)")
async def act_hunt(i: discord.Interaction):
    u, d = ensure_user(i.guild_id, i.user.id); ok, msg = cooldown_check(u, "last_hunt", 60)
    if not ok: return await i.response.send_message(msg, ephemeral=True)
    item, val = random.choice(HUNT_POOL)
    u["coins"] += val; u["stats"]["hunt"] = u["stats"].get("hunt", 0) + 1; save_user(i.guild_id, i.user.id, u, d)
    await i.response.send_message(embed=E(f"> Săn được **{item}**!\n> 💰 `+{val}` {CURRENCY}", "🏹 RỪNG SÂU", "success"))

# ============================================================
# 🎮 GAMES GROUP
# ============================================================
games_g = G("games", "🎮 Trò chơi")

@games_g.command(name="slot", description="🎰 Máy đánh bạc")
async def games_slot(i: discord.Interaction, bet: int):
    if bet <= 0: return await i.response.send_message("❌ Cược > 0!", ephemeral=True)
    u, d = ensure_user(i.guild_id, i.user.id)
    if u.get("coins", 0) < bet: return await i.response.send_message("❌ Không đủ coin!", ephemeral=True)
    reels = ["🍒","🍋","🍊","🍇","💎","7️⃣","⭐"]; res = [random.choice(reels) for _ in range(3)]
    if res[0] == res[1] == res[2]:
        payout = bet*5 if res[0] == "7️⃣" else bet*3
        u["coins"] += payout - bet; msg, color = f"🎉 **JACKPOT!** `+{payout-bet:,}`", "gold"
    elif res[0] == res[1] or res[1] == res[2] or res[0] == res[2]:
        payout = int(bet*1.5); u["coins"] += payout - bet; msg, color = f"✨ Trúng 2! `+{payout-bet:,}`", "success"
    else:
        u["coins"] -= bet; msg, color = f"💀 Thua! `-{bet:,}`", "danger"
    save_user(i.guild_id, i.user.id, u, d); add_quest_progress(i.guild_id, i.user.id, "game")
    await i.response.send_message(embed=E(f"## {' | '.join(res)}\n\n> {msg}\n> 💰 Còn: `{u['coins']:,}`", "🎰 SLOT", color))

@games_g.command(name="trivia", description="🧠 Trắc nghiệm")
async def games_trivia(i: discord.Interaction):
    q = random.choice(TRIVIA)
    await i.response.send_message(embed=E(f"**{q['q']}**\n\n⏰ 30s!", "🧠 TRIVIA", "purple"), view=TriviaView(q))

@games_g.command(name="poll", description="📊 Bình chọn")
async def games_poll(i: discord.Interaction, question: str, option1: str, option2: str, option3: str = None, option4: str = None):
    options = [o for o in [option1, option2, option3, option4] if o]
    view = PollView(question[:200], options)
    await i.response.send_message(embed=view.make_embed(), view=view)

@games_g.command(name="rps", description="🎮 Oẳn tù tì")
@app_commands.choices(choice=[app_commands.Choice(name="✊ Búa",value="rock"),app_commands.Choice(name="✋ Bao",value="paper"),app_commands.Choice(name="✌️ Kéo",value="scissors")])
async def games_rps(i: discord.Interaction, choice: app_commands.Choice[str]):
    emoji = {"rock":"✊","paper":"✋","scissors":"✌️"}; bot_c = random.choice(["rock","paper","scissors"]); u_c = choice.value
    if u_c == bot_c: res, col = "🤝 HÒA!", "warning"
    elif (u_c, bot_c) in (("rock","scissors"),("paper","rock"),("scissors","paper")): res, col = "🎉 THẮNG!", "success"
    else: res, col = "💀 THUA!", "danger"
    await i.response.send_message(embed=E(f"> Bạn: {emoji[u_c]}\n> Bot: {emoji[bot_c]}\n\n## {res}", "🎮 RPS", col))

@games_g.command(name="8ball", description="🎱 Quả cầu 8 bóng")
async def games_8ball(i: discord.Interaction, question: str):
    e = E(title="🎱 8 BALL", color="dark")
    e.add_field(name="❓", value=f"> *{question[:500]}*", inline=False)
    e.add_field(name="🔮", value=f"> **{random.choice(BALL8)}**", inline=False)
    e.set_footer(text=f"Hỏi bởi {i.user.display_name}", icon_url=i.user.display_avatar.url)
    await i.response.send_message(embed=e)

@games_g.command(name="coinflip", description="🪙 Tung đồng xu")
async def games_coinflip(i: discord.Interaction):
    await i.response.send_message(embed=E(f"**{random.choice(['🌕 NGỬA','🌑 SẤP'])}**", "🪙 COINFLIP", "gold"))

@games_g.command(name="dice", description="🎲 Đổ xúc xắc")
async def games_dice(i: discord.Interaction, faces: int = 6):
    if not (2 <= faces <= 100): return await i.response.send_message("❌ 2-100!", ephemeral=True)
    r = random.randint(1, faces)
    await i.response.send_message(embed=E(f"## {DICE_EMOJI.get(r,'🎲')} **{r}**", f"🎲 XÚC XẮC {faces}", "info"))

@games_g.command(name="blackjack", description="🃏 Blackjack (thêm opponent để PvP)")
async def games_blackjack(i: discord.Interaction, bet: int, opponent: discord.Member = None):
    if bet <= 0: return await i.response.send_message("❌ Cược > 0!", ephemeral=True)
    u, d = ensure_user(i.guild_id, i.user.id)
    if u.get("coins", 0) < bet: return await i.response.send_message("❌ Không đủ coin!", ephemeral=True)
    if opponent and not opponent.bot and opponent.id != i.user.id:
        ch = BlackjackChallenge(i.user, opponent, bet)
        return await i.response.send_message(content=opponent.mention, embed=ch._embed(), view=ch)
    def draw(): return random.choice([1,2,3,4,5,6,7,8,9,10,10,10,10,11])
    def score(h):
        t, a = sum(h), h.count(11)
        while t > 21 and a > 0: t -= 10; a -= 1
        return t
    p, b = [draw(), draw()], [draw(), draw()]
    while score(p) < 15: p.append(draw())
    while score(b) < 17: b.append(draw())
    ps, bs = score(p), score(b)
    if ps > 21: outcome, delta, col = "💥 QUẮC!", -bet, "danger"
    elif bs > 21: outcome, delta, col = "🎉 BOT QUẮC!", bet, "gold"
    elif ps > bs: outcome, delta, col = "🎉 THẮNG!", bet, "gold"
    elif ps < bs: outcome, delta, col = "💀 THUA!", -bet, "danger"
    else: outcome, delta, col = "🤝 HÒA!", 0, "warning"
    u["coins"] += delta; save_user(i.guild_id, i.user.id, u, d); add_quest_progress(i.guild_id, i.user.id, "game")
    await i.response.send_message(embed=E(f"🎴 Bạn: {' '.join(CARD_EMOJI[c] for c in p)} → `{ps}`\n🤖 Bot: {' '.join(CARD_EMOJI[c] for c in b)} → `{bs}`\n\n## {outcome}\n> 💰 Còn: `{u['coins']:,}`", "🃏 BLACKJACK", col))

@games_g.command(name="taixiu", description="🎲 Tài Xỉu")
@app_commands.choices(cuoc=[app_commands.Choice(name="🎲 Tài (11-18)",value="tai"),app_commands.Choice(name="🎲 Xỉu (3-10)",value="xiu")])
async def games_taixiu(i: discord.Interaction, cuoc: app_commands.Choice[str], bet: int):
    if bet <= 0: return await i.response.send_message("❌ Cược > 0!", ephemeral=True)
    u, d = ensure_user(i.guild_id, i.user.id)
    if u.get("coins", 0) < bet: return await i.response.send_message("❌ Không đủ coin!", ephemeral=True)
    dices = [random.randint(1, 6) for _ in range(3)]; total = sum(dices)
    result = "tai" if total >= 11 else "xiu"
    if cuoc.value == result: u["coins"] += bet; desc, col = f"**THẮNG!** `+{bet:,}`", "gold"
    else: u["coins"] -= bet; desc, col = f"**THUA!** `-{bet:,}`", "danger"
    save_user(i.guild_id, i.user.id, u, d); add_quest_progress(i.guild_id, i.user.id, "game")
    await i.response.send_message(embed=E(f"## {' '.join(DICE_EMOJI[x] for x in dices)} = **{total}**\n> **{result.upper()}**\n\n{desc}\n> 💰 `{u['coins']:,}`", "🎲 TÀI XỈU", col))

@games_g.command(name="roulette", description="🎰 Roulette")
@app_commands.choices(mau=[app_commands.Choice(name="🔴 Đỏ (x2)",value="red"),app_commands.Choice(name="⚫ Đen (x2)",value="black"),app_commands.Choice(name="🟢 Xanh (x15)",value="green")])
async def games_roulette(i: discord.Interaction, mau: app_commands.Choice[str], bet: int):
    if bet <= 0: return await i.response.send_message("❌ Cược > 0!", ephemeral=True)
    u, d = ensure_user(i.guild_id, i.user.id)
    if u.get("coins", 0) < bet: return await i.response.send_message("❌ Không đủ coin!", ephemeral=True)
    roll = random.randint(0, 36)
    reds = {1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36}
    color = "green" if roll == 0 else ("red" if roll in reds else "black")
    emoji = {"red":"🔴","black":"⚫","green":"🟢"}[color]
    if mau.value == color:
        profit = bet*14 if color == "green" else bet; u["coins"] += profit
        desc, col = f"**THẮNG!** `+{profit:,}`", "gold"
    else: u["coins"] -= bet; desc, col = f"**THUA!** `-{bet:,}`", "danger"
    save_user(i.guild_id, i.user.id, u, d); add_quest_progress(i.guild_id, i.user.id, "game")
    await i.response.send_message(embed=E(f"## {emoji} **{roll}** {color.upper()}\n\n{desc}\n> 💰 `{u['coins']:,}`", "🎰 ROULETTE", col))

@games_g.command(name="truth", description="🎭 Truth")
async def games_truth(i: discord.Interaction):
    qs = ["Bí mật lớn nhất?","Người bạn thích nhất server?","Lần cuối khóc?","Điều xấu hổ nhất từng làm?","Bạn từng nói dối điều gì lớn nhất?"]
    await i.response.send_message(embed=E(f"**{random.choice(qs)}**", "🎭 TRUTH", "pink"))

@games_g.command(name="dare", description="🔥 Dare")
async def games_dare(i: discord.Interaction):
    qs = ["Gửi 1 tin nhắn ngọt ngào cho người trên cùng!","Đổi avatar thành meme trong 1 giờ!","Tag 3 người và khen mỗi người 1 câu!","Hát 1 câu bất kỳ trong voice!","Đổi nickname thành tên đồ ăn trong 1 giờ!"]
    await i.response.send_message(embed=E(f"**{random.choice(qs)}**", "🔥 DARE", "danger"))

# ============================================================
# 🟩 WORDLE GROUP
# ============================================================
wordle_g = G("wordle", "🟩 Wordle hàng ngày")

@wordle_g.command(name="view", description="🟩 Xem lịch sử Wordle")
async def wordle_view(i: discord.Interaction):
    w, _ = ensure_wordle(i.guild_id); guesses = w["guesses"].get(str(i.user.id), [])
    lines = [f"`{g}` → {res}" for g, res in guesses] or ["*Chưa đoán*"]
    e = E(f"> Ngày: **{today()}**\n> **5 chữ cái**\n\n**Lịch sử:**\n" + "\n".join(lines), "🟩 WORDLE", "success")
    e.set_footer(text=f"{len(guesses)}/6 · Đúng +300")
    await i.response.send_message(embed=e, ephemeral=True)

@wordle_g.command(name="guess", description="🟩 Đoán từ")
async def wordle_guess(i: discord.Interaction, tu: str):
    w, data = ensure_wordle(i.guild_id); guess = tu.upper().strip(); uid = str(i.user.id)
    guesses = w["guesses"].get(uid, [])
    if len(guess) != 5 or not guess.isalpha() or not guess.isascii():
        return await i.response.send_message("❌ 5 chữ cái a-z!", ephemeral=True)
    if any(r == "🟩🟩🟩🟩🟩" for _, r in guesses): return await i.response.send_message("✅ Bạn đã giải xong hôm nay!", ephemeral=True)
    if len(guesses) >= 6: return await i.response.send_message("❌ Hết lượt!", ephemeral=True)
    if any(g == guess for g, _ in guesses): return await i.response.send_message("❌ Đã đoán từ này!", ephemeral=True)
    result = wordle_result(guess, w["word"]); guesses.append([guess, result]); w["guesses"][uid] = guesses; save_data(data)
    if guess == w["word"]:
        add_coins(i.guild_id, i.user.id, 300)
        wins = data.setdefault("wordle_wins", {}).setdefault(str(i.guild_id), {}); wins[uid] = wins.get(uid, 0) + 1; save_data(data)
        e = E(f"`{guess}` → {result}\n\n> Từ: **{w['word']}**\n> 🏆 `+300` {CURRENCY} ({len(guesses)}/6)", "🎉 CHÍNH XÁC!", "gold")
    else:
        e = E(f"`{guess}` → {result}\n\n> Còn **{6-len(guesses)}/6**\n> 🟩 đúng · 🟨 sai vị trí · ⬛ không có", "🟩 KẾT QUẢ", "info")
    await i.response.send_message(embed=e, ephemeral=True)

@wordle_g.command(name="hint", description="💡 Gợi ý 1 chữ (50 coin)")
async def wordle_hint(i: discord.Interaction):
    w, data = ensure_wordle(i.guild_id); uid = str(i.user.id)
    used = w.get("hints", {}).get(uid, []); word = w["word"]
    available = [k for k in range(5) if k not in used]
    if not available: return await i.response.send_message(embed=E("Đã biết hết!", "🔒 HẾT", "warning"), ephemeral=True)
    u, d = ensure_user(i.guild_id, i.user.id)
    if u.get("coins", 0) < WORDLE_HINT_PRICE:
        return await i.response.send_message(f"❌ Cần `{WORDLE_HINT_PRICE}` (có `{u.get('coins',0)}`)!", ephemeral=True)
    idx = random.choice(available); used.append(idx); w.setdefault("hints", {})[uid] = used
    u["coins"] -= WORDLE_HINT_PRICE; save_data(data)
    revealed = " ".join(f"`{c.upper()}`" if k in used else "`_`" for k, c in enumerate(word))
    await i.response.send_message(embed=E(f"> 🎁 Vị trí **{idx+1}**: `{word[idx].upper()}`\n> 📝 **{revealed}**\n> 💰 Đã trả: `-{WORDLE_HINT_PRICE}`", "💡 GỢI Ý", "success"), ephemeral=True)

@wordle_g.command(name="top", description="🏆 Top Wordle (số lần giải đúng)")
async def wordle_top(i: discord.Interaction):
    scores = load_data().get("wordle_wins", {}).get(str(i.guild_id), {})
    if not scores: return await i.response.send_message("Chưa ai giải đúng!", ephemeral=True)
    top = sorted(scores.items(), key=lambda x: -x[1])[:10]
    lines = [f"{medal(k)} <@{uid}> — `{sc}` lần" for k, (uid, sc) in enumerate(top)]
    await i.response.send_message(embed=E("\n".join(lines), "🏆 TOP WORDLE", "gold"))

# ============================================================
# 🎯 GUESS GROUP
# ============================================================
guess_g = G("guess", "🎯 Trò chơi đoán")

@guess_g.command(name="music", description="🎵 [Admin] Đoán nhạc")
async def guess_music(i: discord.Interaction, answer: str, hint: str = "Nhạc Việt"):
    if not is_admin(i): return await i.response.send_message("❌ Admin!", ephemeral=True)
    if i.channel_id in active_guesses: return await i.response.send_message("❌ Đang có round!", ephemeral=True)
    active_guesses[i.channel_id] = {"type":"music","answer":answer.strip().upper(),"hint":hint,"active":True}
    await i.response.send_message(embed=E(f"> 🎧 Đoán bài hát!\n> 💡 **{hint}**\n\n⌨️ Gõ đáp án\n🏆 `+200`", "🎵 ĐOÁN NHẠC", "purple"))

@guess_g.command(name="image", description="🖼️ [Admin] Đoán hình")
async def guess_image(i: discord.Interaction, answer: str, image_url: str):
    if not is_admin(i): return await i.response.send_message("❌ Admin!", ephemeral=True)
    if i.channel_id in active_guesses: return await i.response.send_message("❌ Đang có round!", ephemeral=True)
    if not re.match(r"^https?://", image_url): return await i.response.send_message("❌ URL ảnh không hợp lệ!", ephemeral=True)
    active_guesses[i.channel_id] = {"type":"image","answer":answer.strip().upper(),"hint":"","active":True}
    e = E("> Đây là gì?\n> 🏆 `+200`", "🖼️ ĐOÁN HÌNH", "info")
    e.set_image(url=image_url)
    await i.response.send_message(embed=e)

@guess_g.command(name="top", description="🏆 Top thánh đoán")
async def guess_top(i: discord.Interaction):
    g = load_data().get("guess_scores", {}).get(str(i.guild_id), {})
    if not g: return await i.response.send_message("Chưa ai đoán!", ephemeral=True)
    top = sorted(g.items(), key=lambda x: -x[1])[:10]
    lines = [f"{medal(k)} <@{uid}> — **{sc}** lần" for k, (uid, sc) in enumerate(top)]
    await i.response.send_message(embed=E("\n".join(lines), "🏆 TOP THÁNH ĐOÁN", "gold"))

# ============================================================
# 🐱 CAT GROUP
# ============================================================
cat_g = G("cat", "🐱 Mèo")

@cat_g.command(name="shop", description="🛒 Shop trang phục")
async def cat_shop(i: discord.Interaction):
    e = E("> `/cat buy <id>` · `/cat dress <loại>`", "🛒 SHOP MÈO", "purple")
    for k, v in SHOP.items():
        e.add_field(name=f"{OUTFIT_EMOJI[k]} {v['name']}", value=f"ID: `{k}`\n💰 `{v['price']}`", inline=True)
    await i.response.send_message(embed=e)

@cat_g.command(name="buy", description="🛒 Mua trang phục")
async def cat_buy(i: discord.Interaction, item_id: str):
    item_id = item_id.lower()
    if item_id not in SHOP: return await i.response.send_message("❌ Không có! `/cat shop`", ephemeral=True)
    cat, _ = get_cat(i.guild_id, i.user.id)
    if not cat: return await i.response.send_message("❌ Server chưa có khu mèo!", ephemeral=True)
    u, d = ensure_user(i.guild_id, i.user.id); item = SHOP[item_id]
    if item_id in u.get("inventory", []): return await i.response.send_message("✅ Đã sở hữu!", ephemeral=True)
    if u.get("coins", 0) < item["price"]:
        return await i.response.send_message(f"❌ Cần `{item['price']}`, có `{u.get('coins',0)}`!", ephemeral=True)
    u["coins"] -= item["price"]; u.setdefault("inventory", []).append(item_id); save_user(i.guild_id, i.user.id, u, d)
    await i.response.send_message(embed=E(f"> Mua **{item['name']}**!\n> 💰 Còn: `{u['coins']:,}`", "🎉 MUA OK!", "gold"), ephemeral=True)

@cat_g.command(name="dress", description="👗 Mặc trang phục")
@app_commands.choices(loai=[app_commands.Choice(name=v["name"], value=k) for k, v in SHOP.items()] + [app_commands.Choice(name="Không có", value="none")])
async def cat_dress(i: discord.Interaction, loai: app_commands.Choice[str]):
    cat, data = get_cat(i.guild_id, i.user.id)
    if not cat: return await i.response.send_message("❌ Server chưa có khu mèo!", ephemeral=True)
    u, _ = ensure_user(i.guild_id, i.user.id)
    if loai.value != "none" and loai.value not in u.get("inventory", []):
        return await i.response.send_message(f"❌ Chưa sở hữu **{loai.name}**!", ephemeral=True)
    cat["outfit"] = loai.value; save_cat(i.guild_id, i.user.id, cat, data)
    await i.response.send_message(embed=E(f"{OUTFIT_EMOJI.get(loai.value,'🐱')} **{cat['name']}** đã mặc **{loai.name}**!", color="pink"), ephemeral=True)

@cat_g.command(name="rename", description="🐱 Đổi tên mèo")
async def cat_rename(i: discord.Interaction, ten: str):
    cat, data = get_cat(i.guild_id, i.user.id)
    if not cat: return await i.response.send_message("❌ Server chưa có khu mèo!", ephemeral=True)
    cat["name"] = ten[:30]; save_cat(i.guild_id, i.user.id, cat, data)
    await i.response.send_message(embed=E(f"Mèo giờ tên **{ten[:30]}**!", "✅ XONG", "success"), ephemeral=True)

@cat_g.command(name="top", description="🏆 BXH mèo")
async def cat_top(i: discord.Interaction):
    gc_ = load_data().get("cats", {}).get(str(i.guild_id))
    if not gc_: return await i.response.send_message("❌ Chưa có khu mèo!", ephemeral=True)
    cats = gc_.get("cats", {})
    if not cats: return await i.response.send_message("Chưa ai có mèo!", ephemeral=True)
    top = sorted(cats.items(), key=lambda x: (x[1]["level"], x[1]["streak"]), reverse=True)[:10]
    lines = [f"{medal(k)} <@{uid}> — **{c['name']}** · Lv.{c['level']} · 🔥{c['streak']}" for k, (uid, c) in enumerate(top)]
    await i.response.send_message(embed=E("\n".join(lines), "🏆 BXH MÈO", "gold"))

@cat_g.command(name="battle", description="⚔️ Mèo đấu mèo")
async def cat_battle(i: discord.Interaction, member: discord.Member):
    if member.bot or member.id == i.user.id: return await i.response.send_message("❌ Không hợp lệ!", ephemeral=True)
    cat1, _ = get_cat(i.guild_id, i.user.id); cat2, _ = get_cat(i.guild_id, member.id, create=False)
    if not cat1 or not cat2: return await i.response.send_message("❌ Cả 2 phải có mèo (dùng `/cat view`)!", ephemeral=True)
    s1 = cat1["level"]*10 + cat1["happiness"] + random.randint(0, 20)
    s2 = cat2["level"]*10 + cat2["happiness"] + random.randint(0, 20)
    winner = i.user if s1 > s2 else member if s2 > s1 else None
    if winner:
        add_coins(i.guild_id, winner.id, 100)
        desc = f"🏆 **{winner.display_name}** thắng `100` {CURRENCY}!"
    else: desc = "🤝 Hòa!"
    await i.response.send_message(embed=E(desc, "⚔️ MÈO ĐẤU", "purple"))

async def _cat_cmd(i, action):
    e, err = cat_action(i.guild_id, i.user, action)
    await i.response.send_message(embed=e, ephemeral=True) if e else await i.response.send_message(err, ephemeral=True)

@cat_g.command(name="view", description="👀 Xem mèo")
async def cat_view(i: discord.Interaction): await _cat_cmd(i, "view")
@cat_g.command(name="feed", description="🍖 Cho ăn")
async def cat_feed(i: discord.Interaction): await _cat_cmd(i, "feed")
@cat_g.command(name="play", description="🎾 Chơi đùa")
async def cat_play(i: discord.Interaction): await _cat_cmd(i, "play")
@cat_g.command(name="pet", description="🤚 Vuốt ve (+streak +coin)")
async def cat_pet(i: discord.Interaction): await _cat_cmd(i, "pet")

# ============================================================
# 🏯 GANG GROUP
# ============================================================
gang_g = G("gang", "🏯 Bang phái")

async def gang_ac(i: discord.Interaction, cur: str):
    cur = cur.lower()
    return [app_commands.Choice(name=g["name"][:100], value=g["name"][:100])
            for g in get_gangs(i.guild_id).values() if cur in g["name"].lower()][:25]

@gang_g.command(name="create", description="🏯 Tạo bang (Admin)")
async def gang_create(i: discord.Interaction, name: str, owner: discord.Member = None):
    if not is_admin(i): return await i.response.send_message("❌ Admin!", ephemeral=True)
    name = name.strip()
    if len(name) < 2 or len(name) > 30: return await i.response.send_message("❌ 2-30 ký tự!", ephemeral=True)
    gangs = get_gangs(i.guild_id)
    if any(g["name"].lower() == name.lower() for g in gangs.values()):
        return await i.response.send_message("❌ Đã tồn tại!", ephemeral=True)
    owner_m = owner or i.user
    if owner_m.bot: return await i.response.send_message("❌ Bot không được!", ephemeral=True)
    ou, od = ensure_user(i.guild_id, owner_m.id)
    if ou.get("gang"): return await i.response.send_message("❌ Người này đã ở bang khác!", ephemeral=True)
    safe = re.sub(r"[^a-z0-9\-]", "-", name.lower()).strip("-")[:80] or "bang"
    try:
        overwrites = {
            i.guild.default_role: discord.PermissionOverwrite(view_channel=False),
            i.guild.me: discord.PermissionOverwrite(view_channel=True, send_messages=True, manage_channels=True, manage_permissions=True),
            owner_m: discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True)
        }
        ch = await i.guild.create_text_channel(name=f"🏯-{safe}", overwrites=overwrites, topic=f"Bang: {name} · Chủ: {owner_m.display_name}")
    except Exception as e: return await i.response.send_message(f"❌ Lỗi: {e}", ephemeral=True)
    gangs[name] = {"name":name,"owner":owner_m.id,"vices":[],"members":[],"channel_id":ch.id,"created":today()}
    ou["gang"] = name; save_user(i.guild_id, owner_m.id, ou, od)
    e = E(f"> 👑 **{owner_m.mention}**\n> 📍 {ch.mention}\n> 📅 {today_date().strftime('%d/%m/%Y')}\n\n"
          f"**HD:** `/gang join` · `/gang kick` · `/gang transfer` · `/gang vice` · `/gang leave`", f"🏯 BANG MỚI: {name}", "gold")
    await i.response.send_message(embed=e)

@gang_g.command(name="join", description="🎫 Xin vào bang")
async def gang_join(i: discord.Interaction, name: str):
    _, gang = find_gang(i.guild_id, name)
    if not gang: return await i.response.send_message("❌ Không tìm thấy!", ephemeral=True)
    if is_gang_member(gang, i.user.id): return await i.response.send_message("❌ Đã ở trong bang!", ephemeral=True)
    u, _ = ensure_user(i.guild_id, i.user.id)
    if u.get("gang"): return await i.response.send_message(f"❌ Bạn đang ở bang **{u['gang']}** — `/gang leave` trước!", ephemeral=True)
    ch = i.guild.get_channel(gang.get("channel_id", 0))
    if not ch: return await i.response.send_message("❌ Kênh bang bị xóa!", ephemeral=True)
    leaders = [gang["owner"]] + gang.get("vices", [])
    view = JoinRequestView(gang["name"], i.user.id, leaders)
    pings = " ".join(f"<@{x}>" for x in leaders)
    await ch.send(content=f"🔔 {pings} — Yêu cầu vào bang!",
                  embed=E(f"> **Người xin:** {i.user.mention}\n> **Bang:** {gang['name']}\n> <t:{int(time.time())}:R>", "🎫 YÊU CẦU", "warning"), view=view)
    await i.response.send_message(f"📨 Đã gửi yêu cầu tới **{gang['name']}**!", ephemeral=True)

@gang_g.command(name="leave", description="🚪 Rời bang")
async def gang_leave(i: discord.Interaction, name: str):
    _, gang = find_gang(i.guild_id, name)
    if not gang: return await i.response.send_message("❌ Không tìm thấy!", ephemeral=True)
    if i.user.id == gang["owner"]: return await i.response.send_message("❌ Chủ bang phải nhượng quyền trước!", ephemeral=True)
    if i.user.id in gang.get("vices", []): gang["vices"].remove(i.user.id)
    elif i.user.id in gang.get("members", []): gang["members"].remove(i.user.id)
    else: return await i.response.send_message("❌ Không ở trong bang!", ephemeral=True)
    save_data(); await gang_channel_remove(i.guild, gang, i.user.id)
    u, d = ensure_user(i.guild_id, i.user.id)
    if u.get("gang") == gang["name"]: u["gang"] = None; save_user(i.guild_id, i.user.id, u, d)
    await i.response.send_message(embed=E(f"> Rời **{gang['name']}**", "🚪 XONG", "info"), ephemeral=True)

@gang_g.command(name="kick", description="🦵 Kick member")
async def gang_kick(i: discord.Interaction, name: str, member: discord.Member):
    _, gang = find_gang(i.guild_id, name)
    if not gang: return await i.response.send_message("❌ Không tìm thấy!", ephemeral=True)
    if not is_gang_leader(gang, i.user.id) and not is_admin(i):
        return await i.response.send_message("❌ Chỉ chủ/phó!", ephemeral=True)
    if member.id == gang["owner"]: return await i.response.send_message("❌ Không thể kick chủ!", ephemeral=True)
    if member.id in gang.get("vices", []):
        if i.user.id != gang["owner"] and not is_admin(i):
            return await i.response.send_message("❌ Chỉ chủ kick được phó!", ephemeral=True)
        gang["vices"].remove(member.id)
    elif member.id in gang.get("members", []): gang["members"].remove(member.id)
    else: return await i.response.send_message("❌ Không ở bang!", ephemeral=True)
    save_data(); await gang_channel_remove(i.guild, gang, member.id)
    u, d = ensure_user(i.guild_id, member.id)
    if u.get("gang") == gang["name"]: u["gang"] = None; save_user(i.guild_id, member.id, u, d)
    await i.response.send_message(embed=E(f"> {member.mention} bị kick khỏi **{gang['name']}**", "🦵 XONG", "danger"))

@gang_g.command(name="vice", description="🎖️ Set/bỏ phó bang (remove=true để bỏ)")
async def gang_vice(i: discord.Interaction, name: str, member: discord.Member, remove: bool = False):
    _, gang = find_gang(i.guild_id, name)
    if not gang: return await i.response.send_message("❌ Không tìm thấy!", ephemeral=True)
    if i.user.id != gang["owner"]: return await i.response.send_message("❌ Chỉ chủ bang!", ephemeral=True)
    vices = gang.setdefault("vices", [])
    if remove:
        if member.id not in vices: return await i.response.send_message("❌ Không phải phó!", ephemeral=True)
        vices.remove(member.id); gang.setdefault("members", []).append(member.id); save_data()
        return await i.response.send_message(embed=E(f"> {member.mention} không còn là phó **{gang['name']}**", "🎖️ BỎ CHỨC", "warning"))
    if member.id not in gang.get("members", []): return await i.response.send_message("❌ Phải là member trước!", ephemeral=True)
    gang["members"].remove(member.id); vices.append(member.id); save_data()
    await i.response.send_message(embed=E(f"> {member.mention} → **Phó bang** của **{gang['name']}**", "🎖️ SET PHÓ", "success"))

@gang_g.command(name="transfer", description="👑 Nhượng quyền chủ bang")
async def gang_transfer(i: discord.Interaction, name: str, member: discord.Member):
    _, gang = find_gang(i.guild_id, name)
    if not gang: return await i.response.send_message("❌ Không tìm thấy!", ephemeral=True)
    if i.user.id != gang["owner"] and not is_admin(i): return await i.response.send_message("❌ Chỉ chủ/admin!", ephemeral=True)
    if not is_gang_member(gang, member.id): return await i.response.send_message("❌ Chưa ở trong bang!", ephemeral=True)
    if member.id == gang["owner"]: return await i.response.send_message("❌ Đã là chủ!", ephemeral=True)
    old = gang["owner"]; gang["owner"] = member.id
    if member.id in gang.get("vices", []): gang["vices"].remove(member.id)
    if member.id in gang.get("members", []): gang["members"].remove(member.id)
    gang.setdefault("members", []).append(old); save_data()
    await i.response.send_message(embed=E(f"> **{gang['name']}**\n> Cựu chủ: <@{old}>\n> Chủ mới: {member.mention}", "👑 NHƯỢNG QUYỀN", "gold"))

@gang_g.command(name="info", description="📋 Thông tin bang")
async def gang_info(i: discord.Interaction, name: str):
    _, gang = find_gang(i.guild_id, name)
    if not gang: return await i.response.send_message("❌ Không tìm thấy!", ephemeral=True)
    ch = i.guild.get_channel(gang.get("channel_id", 0))
    vices = " ".join(f"<@{x}>" for x in gang.get("vices", [])) or "*Chưa có*"
    members = " ".join(f"<@{x}>" for x in gang.get("members", [])) or "*Chưa có*"
    e = E(title=f"🏯 {gang['name']}", color="purple")
    e.add_field(name="👑 Chủ", value=f"<@{gang['owner']}>", inline=True)
    e.add_field(name="📅", value=gang.get("created", "?"), inline=True)
    e.add_field(name="📍", value=ch.mention if ch else "*(đã xóa)*", inline=True)
    e.add_field(name="🎖️ Phó", value=vices[:1000], inline=False)
    e.add_field(name="👥 Thành viên", value=members[:1000], inline=False)
    e.set_footer(text=f"Tổng: {1+len(gang.get('vices',[]))+len(gang.get('members',[]))}")
    await i.response.send_message(embed=e)

@gang_g.command(name="list", description="📚 Danh sách bang")
async def gang_list(i: discord.Interaction):
    gangs = get_gangs(i.guild_id)
    if not gangs: return await i.response.send_message("📭 Chưa có bang nào!", ephemeral=True)
    e = E(title="📚 DANH SÁCH BANG", color="gold")
    for k, g in list(gangs.items())[:25]:
        ch = i.guild.get_channel(g.get("channel_id", 0))
        total = 1 + len(g.get("vices", [])) + len(g.get("members", []))
        e.add_field(name=f"🏯 {g['name']}", value=f"> 👑 <@{g['owner']}>\n> 👥 `{total}`\n> 📍 {ch.mention if ch else '*(xóa)*'}", inline=True)
    await i.response.send_message(embed=e)

@gang_g.command(name="delete", description="🗑️ [Admin] Xóa bang")
async def gang_delete(i: discord.Interaction, name: str):
    if not is_admin(i): return await i.response.send_message("❌ Admin!", ephemeral=True)
    key, gang = find_gang(i.guild_id, name)
    if not gang: return await i.response.send_message("❌ Không tìm thấy!", ephemeral=True)
    ch = i.guild.get_channel(gang.get("channel_id", 0))
    if ch:
        try: await ch.delete(reason=f"Xóa bang bởi {i.user}")
        except Exception: pass
    users = load_data().get("users", {}).get(str(i.guild_id), {})
    for uid in [gang["owner"]] + gang.get("vices", []) + gang.get("members", []):
        u = users.get(str(uid))
        if u and u.get("gang") == gang["name"]: u["gang"] = None
    get_gangs(i.guild_id).pop(key, None); save_data()
    await i.response.send_message(embed=E(f"> Bang **{gang['name']}** đã xóa.", "🗑️ XONG", "danger"))

for _c in (gang_join, gang_leave, gang_kick, gang_vice, gang_transfer, gang_info, gang_delete):
    _c.autocomplete("name")(gang_ac)       # gợi ý tên bang khi gõ lệnh

# ============================================================
# ⭐ RANK GROUP
# ============================================================
rank_g = G("rank", "⭐ Cấp độ")

@rank_g.command(name="view", description="⭐ Xem level")
async def rank_view(i: discord.Interaction, member: discord.Member = None):
    t = member or i.user; u, _ = ensure_user(i.guild_id, t.id)
    lvl, xp = u.get("level", 1), u.get("xp", 0); need = xp_need(lvl)
    e = E(f"**Level {lvl}**\n{get_progress_bar(xp, need, 20, '🟦')}\n`{xp}/{need} XP`", f"⭐ {t.display_name.upper()}", "cyan")
    e.set_thumbnail(url=t.display_avatar.url)
    await i.response.send_message(embed=e)

@rank_g.command(name="top", description="🏆 BXH level")
async def rank_top(i: discord.Interaction):
    users = load_data().get("users", {}).get(str(i.guild_id), {})
    if not users: return await i.response.send_message("Chưa có dữ liệu!", ephemeral=True)
    top10 = sorted(users.items(), key=lambda x: (x[1].get("level", 1), x[1].get("xp", 0)), reverse=True)[:10]
    lines = [f"{medal(k)} <@{uid}> — **Lv.{u.get('level',1)}** · `{u.get('xp',0)} XP`" for k, (uid, u) in enumerate(top10)]
    await i.response.send_message(embed=E("\n".join(lines), "🏆 TOP LEVEL", "purple"))

@rank_g.command(name="profile", description="👤 Hồ sơ đầy đủ")
async def rank_profile(i: discord.Interaction):
    u, _ = ensure_user(i.guild_id, i.user.id)
    lvl, xp = u.get("level", 1), u.get("xp", 0); need = xp_need(lvl)
    cat, _ = get_cat(i.guild_id, i.user.id, create=False)
    e = E(title=f"👤 {i.user.display_name.upper()}", color="cyan")
    e.set_thumbnail(url=i.user.display_avatar.url)
    e.add_field(name="⭐", value=f"**{lvl}**\n{get_progress_bar(xp, need, 10, '🟦')}\n`{xp}/{need} XP`", inline=False)
    e.add_field(name="💰", value=f"`{u.get('coins',0):,}`", inline=True)
    e.add_field(name="💍", value=f"<@{u['married_to']}>" if u.get("married_to") else "Độc thân", inline=True)
    e.add_field(name="🏯", value=f"**{u['gang']}**" if u.get("gang") else "*Không*", inline=True)
    if cat: e.add_field(name=f"🐱 {cat['name']}", value=f"> Lv.{cat['level']} · 🔥{cat['streak']}", inline=False)
    await i.response.send_message(embed=e)

# ============================================================
# 💕 LOVE GROUP
# ============================================================
love_g = G("love", "💕 Tình cảm")

@love_g.command(name="marry", description="💍 Cầu hôn")
async def love_marry(i: discord.Interaction, member: discord.Member):
    if member.bot or member.id == i.user.id: return await i.response.send_message("❌ Không hợp lệ!", ephemeral=True)
    ua, _ = ensure_user(i.guild_id, i.user.id); ub, _ = ensure_user(i.guild_id, member.id)
    if ua.get("married_to"): return await i.response.send_message("❌ Đã kết hôn!", ephemeral=True)
    if ub.get("married_to"): return await i.response.send_message("❌ Người này đã kết hôn!", ephemeral=True)
    await i.response.send_message(content=member.mention, embed=E(f"💍 {i.user.mention} cầu hôn {member.mention}!\n\n> Đồng ý không?", "💒 CẦU HÔN", "pink"), view=MarryView(i.user, member))

@love_g.command(name="divorce", description="💔 Ly hôn")
async def love_divorce(i: discord.Interaction):
    u, d = ensure_user(i.guild_id, i.user.id); pid = u.get("married_to")
    if not pid: return await i.response.send_message("❌ Độc thân!", ephemeral=True)
    p, _ = ensure_user(i.guild_id, pid); u["married_to"] = None
    if p.get("married_to") == i.user.id: p["married_to"] = None
    save_data(d)
    await i.response.send_message(embed=E(f"> {i.user.mention} ly hôn <@{pid}>...", "💔 LY HÔN", "danger"))

@love_g.command(name="ship", description="💘 Ghép đôi")
async def love_ship(i: discord.Interaction, user1: discord.Member, user2: discord.Member = None):
    a, b = user1, user2 or i.user
    pct = (a.id ^ b.id) % 101
    if pct >= 80: comment, color = "💕 Trời sinh một cặp!", "pink"
    elif pct >= 50: comment, color = "💗 Cũng được!", "success"
    elif pct >= 30: comment, color = "💛 Bạn bè...", "warning"
    else: comment, color = "💔 Không hợp!", "danger"
    await i.response.send_message(embed=E(f"{a.mention} 💞 {b.mention}\n\n{get_progress_bar(pct,100,20,'💖')}\n### **{pct}%**\n{comment}", "💘 SHIP METER", color))

@love_g.command(name="hug", description="💞 Ôm")
async def love_hug(i: discord.Interaction, member: discord.Member):
    await i.response.send_message(embed=E(f"🤗 {i.user.mention} ôm {member.mention}!", color="pink"))

@love_g.command(name="slap", description="👋 Tát")
async def love_slap(i: discord.Interaction, member: discord.Member):
    await i.response.send_message(embed=E(f"👋 {i.user.mention} tát {member.mention}!", color="danger"))

# ============================================================
# 🐺 WOLF GROUP
# ============================================================
wolf_g = G("wolf", "🐺 Ma Sói")

@wolf_g.command(name="start", description="🐺 Bắt đầu game")
async def wolf_start(i: discord.Interaction, invite: discord.Member = None):
    if i.guild_id in werewolf_games: return await i.response.send_message("❌ Đang có game!", ephemeral=True)
    view = WerewolfLobby(i.user.id); view.players.append(i.user.id)
    invited = ""
    if invite and not invite.bot and invite.id != i.user.id:
        view.players.append(invite.id); invited = f"\n📨 Đã mời: {invite.mention}"
    e = E(f"> 👑 Host: {i.user.mention}{invited}\n> 🎭 **Vai:** 🐺 Sói · 👁️ Tiên tri · 🏘️ Dân làng\n> 👥 **Đã có:** {len(view.players)}/12\n\n👉 Bấm **Tham gia** · Host **Bắt đầu** (≥4 người)", "🐺 MA SÓI — PHÒNG CHỜ", "dark")
    await i.response.send_message(embed=e, view=view)

@wolf_g.command(name="kill", description="🐺 [Sói] Giết ai đó")
async def wolf_kill(i: discord.Interaction, target: discord.Member):
    g = werewolf_games.get(i.guild_id)
    if not g: return await i.response.send_message("❌ Không có game!", ephemeral=True)
    if g["roles"].get(i.user.id) != "🐺 Sói" or i.user.id not in g["alive"]:
        return await i.response.send_message("❌ Bạn không phải Sói còn sống!", ephemeral=True)
    if target.id not in g["alive"]: return await i.response.send_message("❌ Người này đã chết/không chơi!", ephemeral=True)
    if g["roles"].get(target.id) == "🐺 Sói": return await i.response.send_message("❌ Không cắn đồng bọn!", ephemeral=True)
    g["wolf_kill"] = target.id
    await i.response.send_message(f"🩸 Đã chọn giết **{target.display_name}**!", ephemeral=True)

@wolf_g.command(name="check", description="👁️ [Tiên tri] Soi vai")
async def wolf_check(i: discord.Interaction, target: discord.Member):
    g = werewolf_games.get(i.guild_id)
    if not g: return await i.response.send_message("❌ Không có game!", ephemeral=True)
    if g["roles"].get(i.user.id) != "👁️ Tiên tri" or i.user.id not in g["alive"]:
        return await i.response.send_message("❌ Không phải Tiên tri còn sống!", ephemeral=True)
    await i.response.send_message(f"🔮 **{target.display_name}** là: **{g['roles'].get(target.id,'?')}**", ephemeral=True)

@wolf_g.command(name="sunrise", description="🌅 [Host] Sang ban ngày")
async def wolf_sunrise(i: discord.Interaction):
    g = werewolf_games.get(i.guild_id)
    if not g: return await i.response.send_message("❌ Không có game!", ephemeral=True)
    if i.user.id != g.get("host") and not is_admin(i): return await i.response.send_message("❌ Host!", ephemeral=True)
    victim = g.get("wolf_kill"); msg = "🌅 **BAN NGÀY** — Không ai chết!"
    if victim:
        g["alive"].discard(victim); g["wolf_kill"] = None
        m = await fetch_m(i.guild, victim); msg = f"💀 **{m.display_name if m else 'Ai đó'}** đã bị Sói giết!"
    g["votes"] = {}
    winner = wolf_winner(g)
    if winner:
        werewolf_games.pop(i.guild_id, None)
        return await i.response.send_message(embed=E(f"> {msg}\n\n## {winner}", "🏁 KẾT THÚC", "gold"))
    await i.response.send_message(embed=E(f"> {msg}\n\n🗳️ Vote: `/wolf vote @user`\n> Host `/wolf sunset`", "🌅 BAN NGÀY", "warning"))

@wolf_g.command(name="vote", description="🗳️ Vote treo cổ")
async def wolf_vote(i: discord.Interaction, target: discord.Member):
    g = werewolf_games.get(i.guild_id)
    if not g: return await i.response.send_message("❌ Không có game!", ephemeral=True)
    if i.user.id not in g["alive"]: return await i.response.send_message("❌ Bạn đã chết/không chơi!", ephemeral=True)
    if target.id not in g["alive"]: return await i.response.send_message("❌ Người này đã chết!", ephemeral=True)
    g["votes"][i.user.id] = target.id
    await i.response.send_message(f"✅ Vote **{target.display_name}**", ephemeral=True)

@wolf_g.command(name="sunset", description="🌇 [Host] Kết thúc vote")
async def wolf_sunset(i: discord.Interaction):
    g = werewolf_games.get(i.guild_id)
    if not g: return await i.response.send_message("❌ Không có game!", ephemeral=True)
    if i.user.id != g.get("host") and not is_admin(i): return await i.response.send_message("❌ Host!", ephemeral=True)
    if not g["votes"]: return await i.response.send_message("❌ Chưa vote!", ephemeral=True)
    tally = {}
    for v in g["votes"].values(): tally[v] = tally.get(v, 0) + 1
    top_ = max(tally.items(), key=lambda x: x[1]); ties = [k for k, v in tally.items() if v == top_[1]]
    if len(ties) == 1:
        g["alive"].discard(top_[0]); m = await fetch_m(i.guild, top_[0])
        name = m.display_name if m else "Ai đó"; role = g["roles"].get(top_[0], "?")
        winner = wolf_winner(g)
        await i.response.send_message(embed=E(f"> **{name}** bị xử tử!\n> Vai: **{role}**\n\n{winner or '🌙 Đêm tiếp - `/wolf sunrise`'}", "⚰️ TREO CỔ", "danger"))
        if winner: werewolf_games.pop(i.guild_id, None)
        else: g["votes"] = {}
    else:
        g["votes"] = {}; await i.response.send_message("⚠️ Hòa phiếu — không ai chết!\n🌙 `/wolf sunrise`")

@wolf_g.command(name="end", description="🛑 [Admin] Kết thúc game")
async def wolf_end(i: discord.Interaction):
    if not is_admin(i): return await i.response.send_message("❌ Admin!", ephemeral=True)
    werewolf_games.pop(i.guild_id, None)
    await i.response.send_message("🛑 Đã kết thúc!")

# ============================================================
# 🏆 AUCTION GROUP
# ============================================================
auction_g = G("auction", "🏆 Đấu giá")

@auction_g.command(name="create", description="🏆 [Admin] Tạo phiên đấu giá role")
async def auction_create(i: discord.Interaction, role: discord.Role, starting_bid: int, duration: int = 300):
    if not is_admin(i): return await i.response.send_message("❌ Admin!", ephemeral=True)
    if i.guild_id in active_auctions: return await i.response.send_message("❌ Đang có phiên!", ephemeral=True)
    if starting_bid <= 0 or not (30 <= duration <= 3600):
        return await i.response.send_message("❌ Giá > 0, thời gian 30-3600s!", ephemeral=True)
    if role >= i.guild.me.top_role: return await i.response.send_message("❌ Role này cao hơn role của bot, bot không cấp được!", ephemeral=True)
    active_auctions[i.guild_id] = {"role": role, "bid": starting_bid, "bidder": None, "end": time.time()+duration}
    e = E(f"> 🎁 {role.mention}\n> 💰 Khởi điểm: `{starting_bid:,}`\n> 👤 *Chưa có*\n> ⏳ <t:{int(time.time()+duration)}:R>\n\n👉 **`/auction bid <số_coin>`**!", "🏆 PHIÊN ĐẤU GIÁ", "gold")
    e.set_footer(text=f"Bởi {i.user.display_name}", icon_url=i.user.display_avatar.url)
    await i.response.send_message(embed=e)
    channel, guild = i.channel, i.guild
    async def end_auction():
        await asyncio.sleep(duration)
        a = active_auctions.pop(guild.id, None)
        if not a: return
        if not a["bidder"]:
            return await channel.send(embed=E(f"{a['role'].mention} không ai mua.", "😢 KHÔNG AI", "dark"))
        u, d = ensure_user(guild.id, a["bidder"])
        if u.get("coins", 0) < a["bid"]:
            return await channel.send(f"⚠️ <@{a['bidder']}> không đủ coin, hủy phiên!")
        m = await fetch_m(guild, a["bidder"])
        try:
            if not m: raise RuntimeError("member rời server")
            await m.add_roles(a["role"])          # cấp role TRƯỚC, thành công mới trừ coin
        except Exception:
            return await channel.send(f"⚠️ Không cấp được role cho <@{a['bidder']}> — phiên hủy, **không trừ coin**.")
        u["coins"] -= a["bid"]; save_user(guild.id, a["bidder"], u, d)
        await channel.send(embed=E(f"> 👑 <@{a['bidder']}> THẮNG!\n> 🎁 {a['role'].mention}\n> 💰 `{a['bid']:,}`", "🏆 KẾT THÚC", "gold"))
    t = asyncio.create_task(end_auction()); _bg_tasks.add(t); t.add_done_callback(_bg_tasks.discard)

@auction_g.command(name="bid", description="💰 Đặt giá")
async def auction_bid(i: discord.Interaction, amount: int):
    a = active_auctions.get(i.guild_id)
    if not a: return await i.response.send_message("❌ Không có phiên!", ephemeral=True)
    if amount <= a["bid"]: return await i.response.send_message(f"❌ Phải > `{a['bid']:,}`!", ephemeral=True)
    u, _ = ensure_user(i.guild_id, i.user.id)
    if u.get("coins", 0) < amount: return await i.response.send_message("❌ Không đủ coin!", ephemeral=True)
    a["bid"], a["bidder"] = amount, i.user.id
    await i.response.send_message(embed=E(f"> Bạn giữ: `{amount:,}`\n> Còn `{max(0,int(a['end']-time.time()))}s`", "💰 ĐẶT GIÁ!", "success"), ephemeral=True)

@auction_g.command(name="list", description="📋 Xem phiên đang chạy")
async def auction_list(i: discord.Interaction):
    a = active_auctions.get(i.guild_id)
    if not a: return await i.response.send_message(embed=E("Admin `/auction create`.", "📭 KHÔNG CÓ", "info"), ephemeral=True)
    bidder = f"<@{a['bidder']}>" if a["bidder"] else "*Chưa có*"
    e = E(f"> 🎁 {a['role'].mention}\n> 💰 `{a['bid']:,}`\n> 👤 {bidder}\n> ⏳ `{max(0,int(a['end']-time.time()))}s`", "🏆 ĐANG CHẠY", "gold")
    await i.response.send_message(embed=e)

# ============================================================
# 📅 QUEST GROUP
# ============================================================
quest_g = G("quest", "📅 Nhiệm vụ")

@quest_g.command(name="view", description="📅 Xem nhiệm vụ")
async def quest_view(i: discord.Interaction):
    u, d = ensure_user(i.guild_id, i.user.id)
    q = u.setdefault("quests", {"date":"","list":[],"progress":{}})
    if q.get("date") != today():
        q["date"] = today(); q["list"] = [x["id"] for x in random.sample(QUEST_POOL, 3)]
        q["progress"] = {k: 0 for k in q["list"]}; save_user(i.guild_id, i.user.id, u, d)
    e = E("> Hoàn thành nhiệm vụ để nhận ErrorCoin!\n\u200b", "📅 NHIỆM VỤ HÀNG NGÀY", "info")
    for qid in q["list"]:
        item = next((x for x in QUEST_POOL if x["id"] == qid), None)
        if item:
            prog = q["progress"].get(qid, 0)
            if q["progress"].get(f"{qid}_claimed"): stt = "🎁 **Đã nhận**"
            elif prog >= item["goal"]: stt = "✅ **Xong - `/quest claim`**"
            else: stt = f"⏳ `{prog}/{item['goal']}`"
            e.add_field(name=f"🔹 {item['desc']}", value=f"{stt}\n> 💰 `{item['reward']}` {CURRENCY}", inline=False)
    await i.response.send_message(embed=e, ephemeral=True)

@quest_g.command(name="claim", description="🎁 Nhận thưởng nhiệm vụ")
async def quest_claim(i: discord.Interaction):
    u, d = ensure_user(i.guild_id, i.user.id); q = u.get("quests", {}); claimed, total = 0, 0
    if q.get("date") != today(): return await i.response.send_message("❌ Không có gì để nhận!", ephemeral=True)
    for qid in q.get("list", []):
        item = next((x for x in QUEST_POOL if x["id"] == qid), None)
        if item and q["progress"].get(qid, 0) >= item["goal"] and not q["progress"].get(f"{qid}_claimed"):
            q["progress"][f"{qid}_claimed"] = True; total += item["reward"]; claimed += 1
    if claimed == 0: return await i.response.send_message("❌ Không có gì để nhận!", ephemeral=True)
    u["coins"] += total; save_user(i.guild_id, i.user.id, u, d)
    await i.response.send_message(embed=E(f"🎁 Nhận **{claimed}** nhiệm vụ!\n> 💰 `+{total}` {CURRENCY}", color="success"), ephemeral=True)

@quest_g.command(name="achievements", description="🏆 Thành tựu")
async def quest_achievements(i: discord.Interaction):
    u, _ = ensure_user(i.guild_id, i.user.id); unlocked = u.get("achievements", [])
    e = E(title="🏆 THÀNH TỰU", color="gold")
    for aid, a in ACHIEVEMENTS.items():
        e.add_field(name=f"{'✅' if aid in unlocked else '🔒'} {a['name']}", value=f"*{a['desc']}*\nThưởng: `{a['reward']}`", inline=True)
    await i.response.send_message(embed=e, ephemeral=True)

# ============================================================
# 👑 SPECIAL GROUP
# ============================================================
special_g = G("special", "👑 Đặc biệt")

@special_g.command(name="roles", description="👑 Role thần thoại")
async def special_roles(i: discord.Interaction):
    e = E("> Grant: `/setup grantrole`\n━━━━━━━━━━━━━━━━━━━━", "👑 ROLE THẦN THOẠI", "purple")
    e.add_field(name=f"💖 {SPECIAL_ROLE_AMATERASU}", value="Role danh dự", inline=False)
    e.add_field(name=f"🤑 {SPECIAL_ROLE_YAMATE}", value="✅ `/special say` — Bot nói hộ", inline=False)
    e.add_field(name=f"🌙 {SPECIAL_ROLE_TSUKUYOMI}", value="Role danh dự", inline=False)
    e.add_field(name=f"⚡ {SPECIAL_ROLE_SUSANOO}", value="Role danh dự", inline=False)
    e.add_field(name=f"💀 {SPECIAL_ROLE_IZANAMI}", value="Role danh dự", inline=False)
    await i.response.send_message(embed=e)

@special_g.command(name="say", description="🤑 [yamate] Bot nói hộ")
async def special_say(i: discord.Interaction, text: str):
    if not has_special_role(i, SPECIAL_ROLE_YAMATE) and not is_admin(i):
        return await i.response.send_message(f"❌ Cần role **{SPECIAL_ROLE_YAMATE}**!", ephemeral=True)
    await i.response.send_message("✅", ephemeral=True)
    await i.channel.send(text[:1900], allowed_mentions=discord.AllowedMentions.none())

# ============================================================
# 🌐 WEB GROUP (lệnh Discord liên quan tới web)
# ============================================================
web_g = G("web", "🌐 Web Dashboard & Vòng quay")

@web_g.command(name="login", description="🌐 Cấp MẬT KHẨU MỚI & xem tài khoản web")
async def web_login(i: discord.Interaction):
    acc, pw = reset_web_password(i.guild_id, i.user.id, i.user.display_name)
    await i.response.send_message(embed=cred_embed(acc, pw, "🌐 TÀI KHOẢN WEB CỦA BẠN"), ephemeral=True)

@web_g.command(name="spin", description="🎡 Luật & hướng dẫn vòng quay (1000 coin/lượt)")
async def web_spin_cmd(i: discord.Interaction):
    acc, _ = ensure_web_account(i.guild_id, i.user.id, i.user.display_name)
    link = WEB_URL or "*(chủ bot chưa đặt WEB_URL)*"
    e = E(f"> 🔗 Web: {link}\n> 👤 Username: `{acc['username']}` (quên mật khẩu → `/web login`)\n\n"
          f"**Luật chơi:**\n> 💰 Mỗi lượt: `{WHEEL_COST:,}` {CURRENCY} (trừ ở server bạn chọn)\n"
          f"> 🎁 5% Roblox · 5% Liên Quân · 5% Free Fire · 5% +{WHEEL_COIN_PRIZE:,} xu · 80% Chúc may mắn\n"
          f"> 🏆 Trúng acc → nhận ticket, liên hệ chủ server qua {SUPPORT_INVITE}\n> 🎡 Bạn đã quay: **{acc.get('spun',0)}** lần",
          "🎡 VÒNG QUAY MAY MẮN", "pink")
    await i.response.send_message(embed=e, ephemeral=True)

@web_g.command(name="top", description="🌐 BXH server (ErrorCoin / Level / Mèo)")
async def web_top(i: discord.Interaction):
    data = load_data(); gid = str(i.guild_id)
    users = data.get("users", {}).get(gid, {})
    top_coin = sorted(users.items(), key=lambda x: -(x[1].get("coins",0)+x[1].get("bank",0)))[:5]
    top_lv = sorted(users.items(), key=lambda x: (x[1].get("level",1), x[1].get("xp",0)), reverse=True)[:5]
    cats = data.get("cats", {}).get(gid, {}).get("cats", {})
    top_cat = sorted(cats.items(), key=lambda x: (x[1]["level"], x[1]["streak"]), reverse=True)[:5]
    e = E(title=f"🌐 BXH SERVER {i.guild.name}", color="gold")
    e.add_field(name="💰 TOP ERRORCOIN", value="\n".join(f"{medal(k)} <@{uid}> `{(u.get('coins',0)+u.get('bank',0)):,}`" for k, (uid, u) in enumerate(top_coin)) or "*Trống*", inline=False)
    e.add_field(name="⭐ TOP LEVEL", value="\n".join(f"{medal(k)} <@{uid}> **Lv.{u.get('level',1)}**" for k, (uid, u) in enumerate(top_lv)) or "*Trống*", inline=False)
    e.add_field(name="🐱 TOP MÈO", value="\n".join(f"{medal(k)} <@{uid}> **{c['name']}** Lv.{c['level']}" for k, (uid, c) in enumerate(top_cat)) or "*Trống*", inline=False)
    e.set_footer(text="Xem đầy đủ tại web dashboard")
    await i.response.send_message(embed=e)

@web_g.command(name="help", description="🌐 Hướng dẫn web")
async def web_help(i: discord.Interaction):
    e = E("**Bước 1:** `/web login` để lấy username/password (hoặc xem DM bot gửi).\n"
          f"**Bước 2:** Mở web: {WEB_URL or '*(hỏi chủ bot)*'} → nhập username/password.\n"
          f"**Bước 3:** Dashboard có xếp hạng ErrorCoin/Level/Mèo + **Vòng quay** ({WHEEL_COST:,} coin/lượt).\n"
          "**Bước 4:** Trúng acc → nhận ticket, chủ server liên hệ bạn.\n\n"
          f"**Server hỗ trợ:** {SUPPORT_INVITE}\n\n**Giải thưởng:**\n"
          "> 🎮 `CUHAJS` → 1 ACC ROBLOX (5%)\n> ⚔️ `HIJKOU` → 1 ACC LIÊN QUÂN (5%)\n> 🔫 `MOAUSS` → 1 ACC FREE FIRE (5%)\n"
          f"> 💰 `LLOUAS` → +{WHEEL_COIN_PRIZE:,} {CURRENCY} (5%)\n> 🍀 `UIAUIA` / `AIUAIU` → Chúc may mắn (80%)",
          "🌐 HƯỚNG DẪN WEB", "cyan")
    await i.response.send_message(embed=e, ephemeral=True)

@web_g.command(name="prizes", description="🎁 Xem giải/ticket của bạn")
async def web_prizes(i: discord.Interaction):
    ts = [t for t in load_data().get("tickets", []) if t["discord_id"] == i.user.id][-10:]
    if not ts: return await i.response.send_message("📭 Bạn chưa trúng acc nào.", ephemeral=True)
    lines = [f"{'✅' if t['done'] else '⏳'} `{t['ticket']}` — **{t['prize']}** · {t['time']}" for t in ts]
    await i.response.send_message(embed=E("\n".join(lines), "🎁 GIẢI CỦA BẠN", "gold"), ephemeral=True)

@web_g.command(name="tickets", description="📋 [Owner/Admin] Ticket chưa trao")
async def web_tickets_cmd(i: discord.Interaction):
    if not is_owner_or_admin(i): return await i.response.send_message("❌ Chỉ owner/admin!", ephemeral=True)
    ts = [t for t in load_data().get("tickets", []) if not t["done"]][-20:]
    if not ts: return await i.response.send_message("✅ Không có ticket nào chờ.", ephemeral=True)
    lines = [f"`{t['ticket']}` — <@{t['discord_id']}> · **{t['prize']}** · {t['guild_name']}" for t in ts]
    await i.response.send_message(embed=E("\n".join(lines), "📋 TICKET CHỜ TRAO", "warning"), ephemeral=True)

@web_g.command(name="done", description="✅ [Owner/Admin] Đánh dấu ticket đã trao")
async def web_done_cmd(i: discord.Interaction, ticket: str):
    if not is_owner_or_admin(i): return await i.response.send_message("❌ Chỉ owner/admin!", ephemeral=True)
    ok = web_ticket_done(ticket.strip().upper())
    await i.response.send_message("✅ Đã đánh dấu!" if ok else "❌ Không tìm thấy ticket!", ephemeral=True)

# ============================================================
# 🌐 WEB BRIDGE — các hàm này CHỈ chạy trên event-loop của bot
# ============================================================
def _wname(web, uid): return web.get(uid, {}).get("discord_name") or f"User {uid[-4:]}"

def _gname(gid):
    g = bot.get_guild(int(gid))
    return g.name if g else (load_data().get("guilds", {}).get(str(gid), {}).get("name") or f"Guild {gid}")

def web_account(username):
    for uid, a in load_data().get("web_accounts", {}).items():
        if a.get("username") == username:
            if "password" in a: a["pw_hash"] = hash_pw(a.pop("password")); save_data()
            return {"uid": uid, "pw_hash": a.get("pw_hash", "")}
    return None

def web_me(uid, gid=None):
    data = load_data(); users = data.get("users", {}); web = data.get("web_accounts", {})
    mine = [g for g, us in users.items() if uid in us]
    if not mine: return {"error": "Chưa có dữ liệu — hãy nhắn tin ở server có bot trước nhé."}
    gid = gid if gid in mine else mine[0]
    gu = users[gid]; u = gu[uid]
    by_coin = sorted(gu.items(), key=lambda x: -(x[1].get("coins", 0) + x[1].get("bank", 0)))
    by_lv = sorted(gu.items(), key=lambda x: (x[1].get("level", 1), x[1].get("xp", 0)), reverse=True)
    cats = data.get("cats", {}).get(gid, {}).get("cats", {})
    by_cat = sorted(cats.items(), key=lambda x: (x[1]["level"], x[1]["streak"]), reverse=True)
    pos = lambda lst: next((k + 1 for k, (x, _) in enumerate(lst) if x == uid), None)
    cat = cats.get(uid); acc = web.get(uid, {})
    tickets = [t for t in data.get("tickets", []) if str(t["discord_id"]) == uid][-10:]
    return {
        "gid": gid, "guilds": [{"id": g, "name": _gname(g)} for g in mine],
        "name": acc.get("discord_name", ""), "username": acc.get("username", ""),
        "coins": u.get("coins", 0) + u.get("bank", 0), "wallet": u.get("coins", 0), "bank": u.get("bank", 0),
        "level": u.get("level", 1), "xp": u.get("xp", 0), "need_xp": xp_need(u.get("level", 1)),
        "rank_coin": pos(by_coin), "rank_level": pos(by_lv), "rank_cat": pos(by_cat),
        "cat_name": cat["name"] if cat else None, "cat_level": cat["level"] if cat else 0, "cat_streak": cat["streak"] if cat else 0,
        "spun": acc.get("spun", 0), "wheel_cost": WHEEL_COST,
        "top_coin": [{"name": _wname(web, x), "value": v.get("coins", 0) + v.get("bank", 0), "me": x == uid} for x, v in by_coin[:10]],
        "top_level": [{"name": _wname(web, x), "value": v.get("level", 1), "me": x == uid} for x, v in by_lv[:10]],
        "top_cat": [{"name": _wname(web, x), "value": f"{c['name']} · Lv.{c['level']} · 🔥{c['streak']}", "me": x == uid} for x, c in by_cat[:10]],
        "tickets": [{"ticket": t["ticket"], "prize": t["prize"], "time": t["time"], "done": t["done"]} for t in tickets],
    }

def web_spin(uid, gid):
    data = load_data(); acc = data.get("web_accounts", {}).get(uid)
    if not acc: return {"error": "Tài khoản không tồn tại"}
    u = data.get("users", {}).get(str(gid), {}).get(uid)
    if not u: return {"error": "Bạn chưa có dữ liệu ở server này"}
    now = time.time()
    if now - acc.get("last_spin", 0) < 2: return {"error": "Quay chậm thôi!"}
    total = u.get("coins", 0) + u.get("bank", 0)
    if total < WHEEL_COST: return {"error": f"Không đủ ErrorCoin (có {total:,}, cần {WHEEL_COST:,})"}
    acc["last_spin"] = now
    take = min(WHEEL_COST, u["coins"]); u["coins"] -= take; u["bank"] = u.get("bank", 0) - (WHEEL_COST - take)
    r = _rng.random(); code, ptype, pname, coin_amt = WHEEL_PRIZES[-1][1:]
    for thr, c, t, n, coins in WHEEL_PRIZES:
        if r <= thr: code, ptype, pname, coin_amt = c, t, n, coins; break
    ticket = ""
    if ptype == "coins": u["coins"] += coin_amt
    elif ptype != "none":
        ticket = "T" + secrets.token_hex(4).upper()
        tk = data.setdefault("tickets", [])
        tk.append({"ticket": ticket, "discord_id": int(uid), "username": acc.get("username", "?"), "guild_id": str(gid),
                   "guild_name": _gname(gid), "prize": pname, "code": code, "type": ptype,
                   "time": datetime.datetime.now(VN_TZ).strftime("%d/%m/%Y %H:%M"), "done": False})
        if len(tk) > 500:                      # giữ nhẹ file: bỏ ticket cũ đã trao
            data["tickets"] = [t for t in tk if not t["done"]] + [t for t in tk if t["done"]][-100:]
        data.setdefault("notif_queue", []).append(ticket)
    acc["spun"] = acc.get("spun", 0) + 1
    unlock_achievement(gid, uid, "web_spin")
    save_data(data)
    return {"ok": True, "win": ptype != "none", "code": code, "prize": pname, "type": ptype, "ticket": ticket,
            "coins_after": u["coins"] + u.get("bank", 0), "spun": acc["spun"]}

def web_overview():
    data = load_data(); meta = data.get("guilds", {}); users = data.get("users", {}); web = data.get("web_accounts", {})
    live = {str(g.id): g for g in bot.guilds}; ready = bot.is_ready(); servers = []
    for gid in set(live) | set(users):
        g = live.get(gid); m = meta.get(gid, {})
        servers.append({"id": gid, "name": g.name if g else m.get("name", f"Guild {gid}"), "alias": m.get("alias", ""),
                        "members": g.member_count if g else len(users.get(gid, {})), "tracked": len(users.get(gid, {})),
                        "online": bool(g) and ready, "url": m.get("url", "")})
    servers.sort(key=lambda s: (not s["online"], (s["alias"] or s["name"]).lower()))
    gn = {s["id"]: s["alias"] or s["name"] for s in servers}
    rows = [(gid, uid, u) for gid, us in users.items() for uid, u in us.items()]
    tc = heapq.nlargest(20, rows, key=lambda r: r[2].get("coins", 0) + r[2].get("bank", 0))
    tl = heapq.nlargest(20, rows, key=lambda r: (r[2].get("level", 1), r[2].get("xp", 0)))
    crow = [(gid, uid, c) for gid, gd in data.get("cats", {}).items() for uid, c in gd.get("cats", {}).items()]
    tcat = heapq.nlargest(20, crow, key=lambda r: (r[2]["level"], r[2]["streak"]))
    return {"bot_online": ready, "latency": round(bot.latency * 1000) if ready else None,
            "uptime": int(time.time() - bot.started), "total_servers": len([s for s in servers if s["online"]]),
            "total_users": len(rows), "total_web_accounts": len(web), "servers": servers,
            "pending_tickets": sum(1 for t in data.get("tickets", []) if not t["done"]),
            "top_coin": [{"name": _wname(web, uid), "value": u.get("coins", 0) + u.get("bank", 0), "guild": gn.get(gid, gid)} for gid, uid, u in tc],
            "top_level": [{"name": _wname(web, uid), "value": u.get("level", 1), "guild": gn.get(gid, gid)} for gid, uid, u in tl],
            "top_cat": [{"name": _wname(web, uid), "value": f"{c['name']} · Lv.{c['level']}", "guild": gn.get(gid, gid)} for gid, uid, c in tcat]}

def web_search(q, gid=""):
    q = q.strip().lower()
    if not q: return []
    data = load_data(); web = data.get("web_accounts", {}); meta = data.get("guilds", {}); res = []
    for g_id, us in data.get("users", {}).items():
        if gid and g_id != gid: continue
        m = meta.get(g_id, {}); cats = data.get("cats", {}).get(g_id, {}).get("cats", {})
        for uid, u in us.items():
            a = web.get(uid, {})
            if q == uid or q in a.get("discord_name", "").lower() or q in a.get("username", "").lower():
                c = cats.get(uid)
                res.append({"discord_id": uid, "name": a.get("discord_name") or uid, "username": a.get("username", ""),
                            "guild_id": g_id, "guild": _gname(g_id), "alias": m.get("alias", ""), "url": m.get("url", ""),
                            "coins": u.get("coins", 0), "bank": u.get("bank", 0), "level": u.get("level", 1),
                            "cat": f"{c['name']} (Lv.{c['level']})" if c else None, "gang": u.get("gang"),
                            "spun": a.get("spun", 0)})
                if len(res) >= 60: return res
    return res

def web_set_guild(gid, alias, url):
    gid = str(gid)
    if gid not in load_data().get("users", {}) and not bot.get_guild(int(gid) if gid.isdigit() else 0): return False
    m = gmeta(gid)
    if alias is not None: m["alias"] = str(alias).strip()[:40]
    if url is not None:
        url = str(url).strip()[:200]
        if url and not re.match(r"^https?://", url): return False
        m["url"] = url
    save_data(); return True

def web_tickets():
    return [t for t in load_data().get("tickets", [])][-100:][::-1]

def web_ticket_done(tid):
    for t in load_data().get("tickets", []):
        if t["ticket"] == tid: t["done"] = True; save_data(); return True
    return False

class WebBridge:
    """Cầu nối thread-safe: mọi truy cập data của web đều chạy trên event-loop của bot."""
    def __init__(self, api_key, secret, cfg):
        self.api_key, self.secret, self.config = api_key, secret, cfg
        self.check_pw = staticmethod(check_pw)
    def _run(self, fn, *a, timeout=15):
        loop = bot.web_loop
        if loop is None or loop.is_closed(): raise RuntimeError("Bot chưa sẵn sàng")
        fut = concurrent.futures.Future()
        def job():
            try: fut.set_result(fn(*a))
            except BaseException as e: fut.set_exception(e)
        loop.call_soon_threadsafe(job)
        return fut.result(timeout)
    def account(self, username): return self._run(web_account, username)
    def me(self, uid, gid=None): return self._run(web_me, uid, gid)
    def spin(self, uid, gid): return self._run(web_spin, uid, gid)
    def overview(self): return self._run(web_overview)
    def search(self, q, gid=""): return self._run(web_search, q, gid)
    def set_guild(self, gid, alias, url): return self._run(web_set_guild, gid, alias, url)
    def tickets(self): return self._run(web_tickets)
    def ticket_done(self, tid): return self._run(web_ticket_done, tid)

def web_settings():
    w = load_data().setdefault("web", {})
    if "secret" not in w: w["secret"] = secrets.token_hex(32)
    if not WEB_API_KEY and "api_key" not in w: w["api_key"] = secrets.token_urlsafe(18)
    save_data(); flush_data()
    return (WEB_API_KEY or w["api_key"]), w["secret"]

def start_web():
    try:
        from webboty import create_app
    except Exception as e:
        print("⚠️ Không chạy được web (cần `pip install Flask`):", e); return
    key, secret = web_settings()
    cfg = {"support": SUPPORT_INVITE, "currency": CURRENCY, "wheel_cost": WHEEL_COST,
           "origins": os.environ.get("WEB_ORIGINS", "*").strip() or "*"}   # vd https://ten-ban.netlify.app
    app = create_app(WebBridge(key, secret, cfg))
    def run():
        try:
            import logging; logging.getLogger("werkzeug").setLevel(logging.ERROR)
            app.run(host="0.0.0.0", port=WEB_PORT, debug=False, threaded=True, use_reloader=False)
        except Exception: traceback.print_exc()
    threading.Thread(target=run, daemon=True, name="web").start()
    print("=" * 56); print(f"🌐 WEB chạy ở cổng {WEB_PORT}" + (f" · {WEB_URL}" if WEB_URL else ""))
    print(f"🔐 ADMIN API KEY: {key}"); print("=" * 56)
    if not WEB_URL and os.environ.get("TUNNEL", "1").strip() != "0":
        start_tunnel(WEB_PORT)          # chưa có URL công khai -> tự mở đường hầm Cloudflare để có link https

# ============================================================
# 🔗 TUNNEL — host không cấp URL web thì bot tự lấy link https://xxxx.trycloudflare.com
# (tắt bằng biến TUNNEL=0; đã đặt WEB_URL thì tự tắt)
# ============================================================
TUNNEL_URL = ""
_TUNNEL_RE = re.compile(r"https://([a-z0-9]+(?:-[a-z0-9]+)+)\.trycloudflare\.com")   # có dấu gạch ngang -> loại "api.trycloudflare.com"

async def _dm_tunnel(url):
    o = await get_owner()
    if o:
        try: await o.send(f"🌐 **Link web mới của bot:** {url}\n> Mở link này là vào được web (tab Admin dùng ADMIN API KEY trong console).\n"
                          f"> Nếu dùng trang Netlify: dán link này vào ô *Địa chỉ bot*.\n> ⚠️ Link đổi mỗi lần bot khởi động lại.")
        except Exception as e: print("⚠️ Không DM được link cho owner:", e)

def _tunnel_announce(url):
    global TUNNEL_URL, WEB_URL
    if url == TUNNEL_URL: return
    TUNNEL_URL = url
    if not os.environ.get("WEB_URL", "").strip(): WEB_URL = url      # để /web login & DM gửi đúng link cho người chơi
    print("=" * 56); print(f"🔗 LINK WEB: {url}"); print("   (đổi mỗi lần bot khởi động lại)"); print("=" * 56)
    try:
        if bot.web_loop: asyncio.run_coroutine_threadsafe(_dm_tunnel(url), bot.web_loop)
    except Exception: pass

def start_tunnel(port):
    def run():
        import platform, subprocess, urllib.request
        try:
            arch = {"x86_64":"amd64","amd64":"amd64","aarch64":"arm64","arm64":"arm64"}.get(platform.machine().lower())
            exe = os.path.join(BASE_DIR, "cloudflared")
            if not os.path.exists(exe):
                if not arch: print("⚠️ Tunnel: CPU không hỗ trợ:", platform.machine()); return
                print("⬇️ Đang tải cloudflared để tạo link web...")
                urllib.request.urlretrieve(f"https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-{arch}", exe + ".tmp")
                os.chmod(exe + ".tmp", 0o755); os.replace(exe + ".tmp", exe)
            fails = 0
            while True:                                   # tự chạy lại nếu tunnel chết
                t0 = time.time()
                p = subprocess.Popen([exe, "tunnel", "--no-autoupdate", "--url", f"http://127.0.0.1:{port}"],
                                     stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
                for line in p.stdout:
                    m = _TUNNEL_RE.search(line)
                    if m: _tunnel_announce(m.group(0))
                p.wait()
                fails = fails + 1 if time.time() - t0 < 60 else 0
                if fails >= 5: print("⚠️ Tunnel liên tục lỗi, dừng thử. Host có thể chặn kết nối ra ngoài."); return
                time.sleep(10)
        except Exception as e:
            print("⚠️ Không tạo được link web tự động:", e, "\n   (host có thể chặn tải file / kết nối ra ngoài)")
    threading.Thread(target=run, daemon=True, name="tunnel").start()

# ============================================================
# 🚀 RUN
# ============================================================
def count_commands():
    return sum(len(c.commands) if isinstance(c, app_commands.Group) else 1 for c in bot.tree.get_commands())

if __name__ == "__main__":
    print(f"⏳ Đang khởi động Bot... ({count_commands()} lệnh)")
    print("☁️ Redis:", "BẬT" if REMOTE_ON else "tắt (dữ liệu chỉ lưu data.json)", "| 🔔 Keepalive:", KEEPALIVE_URL or "tắt")
    token = _load_token()
    if len(token) < 50:
        print("❌ CHƯA CÓ TOKEN! Đặt DISCORD_TOKEN hoặc tạo token.txt.")
        raise SystemExit(1)
    load_data()                                        # kéo dữ liệu từ Redis (nếu bật) trước khi bot chạy
    try: signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))   # host tắt bot -> thoát êm để lưu dữ liệu
    except Exception: pass
    try:
        bot.run(token, log_handler=None)
    except discord.LoginFailure:
        print("❌ TOKEN SAI!")
    except discord.PrivilegedIntentsRequired:
        print("❌ Bật SERVER MEMBERS + MESSAGE CONTENT INTENT!")
    except Exception:
        traceback.print_exc()
    finally:
        flush_data(True)
