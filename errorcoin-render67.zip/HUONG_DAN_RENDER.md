# Đưa bot + web lên Render (miễn phí, KHÔNG cần thẻ)

Render cho link web `https://xxx.onrender.com` miễn phí. Có 2 điểm yếu mà bot đã được chỉnh để xử lý:
- **Ngủ sau 15 phút không có truy cập** → bot tự gọi `/ping` của chính nó mỗi 9 phút để không ngủ.
- **Đĩa bị xóa mỗi lần khởi động lại** → dữ liệu (coin, level, tài khoản web…) được lưu ra **Upstash Redis** (miễn phí). Thiếu bước này là MẤT DỮ LIỆU.

Cần 3 tài khoản miễn phí: **Upstash**, **GitHub**, **Render**. Làm lần lượt:

## Bước 1 — Upstash (nơi lưu dữ liệu)
1. Vào upstash.com, đăng ký (đăng nhập bằng Google/GitHub được).
2. Tạo **Redis database** → chọn gói **Free**, vùng gần Việt Nam (Singapore) → Create.
3. Trong trang database, tìm khu **REST API**, chép 2 giá trị:
   - `UPSTASH_REDIS_REST_URL` (dạng `https://xxxx.upstash.io`)
   - `UPSTASH_REDIS_REST_TOKEN` (chuỗi dài)

## Bước 2 — GitHub (để Render lấy code)
1. Vào github.com → **New repository** → đặt tên (vd `errorcoin-bot`) → chọn **Private** → Create.
2. Bấm **uploading an existing file** (hoặc Add file → Upload files) → kéo thả **5 file trong thư mục này**:
   `boty.py`, `webboty.py`, `requirements.txt`, `render.yaml`, `.gitignore` → **Commit changes**.
> ⚠️ KHÔNG upload `token.txt` hay `data.json`. Token sẽ nhập ở Render (bước 3), không để trong code.

## Bước 3 — Render
1. Vào render.com, đăng ký bằng GitHub.
2. **New +** → **Web Service** → chọn repo vừa tạo (cho Render quyền đọc repo nếu được hỏi).
3. Điền:
   - **Language/Runtime:** Python 3
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `python boty.py`
   - **Instance Type:** **Free**
4. Mục **Environment Variables**, thêm:
   | Tên | Giá trị |
   |---|---|
   | `DISCORD_TOKEN` | token bot (từ Discord Developer Portal → Bot) |
   | `UPSTASH_REDIS_REST_URL` | giá trị ở bước 1 |
   | `UPSTASH_REDIS_REST_TOKEN` | giá trị ở bước 1 |
   | `WEB_API_KEY` | mật khẩu admin do bạn tự đặt (vd `Abc12345xyz`) |
   | `OWNER_ID` | ID Discord của bạn (để bot DM khi có người trúng acc) |
5. Bấm **Create Web Service**. Chờ build xong (vài phút).

## Bước 4 — Mở web
- Render hiển thị link ở đầu trang dịch vụ: `https://tên-của-bạn.onrender.com`. **Mở link đó là vào web luôn** (không cần Netlify).
- Tab **Admin**: nhập `WEB_API_KEY` bạn đã đặt. Tab **Người chơi**: username/mật khẩu bot gửi DM (hoặc `/web login`).
- Console (tab **Logs**) phải có: `☁️ Redis: BẬT`, `Bot ready`, `WEB chạy ở cổng ...`.
- Nếu muốn dùng trang Netlify: ở ô "Địa chỉ bot" dán link Render ở trên.

## Bước 5 (khuyên làm) — UptimeRobot chống ngủ dự phòng
1. uptimerobot.com → đăng ký free → **Add New Monitor** → loại **HTTP(s)**.
2. URL: `https://tên-của-bạn.onrender.com/ping`, tần suất 5 phút.

## Lưu ý
- Bot tự lưu dữ liệu lên Redis mỗi ~2 phút và khi tắt. Nếu Upstash lỗi hoặc sai key, bot **dừng hẳn** (chứ không chạy với dữ liệu rỗng) và in lý do trong Logs.
- Free của Render có 750 giờ/tháng, đủ cho 1 dịch vụ chạy 24/7. Render có thể khởi động lại bot bất cứ lúc nào — dữ liệu vẫn còn nhờ Redis.
- Muốn chuyển dữ liệu cũ từ Pella sang: tải `data.json` từ Pella về, tạm thời upload vào repo (bỏ dòng `data.json` trong `.gitignore`) rồi deploy 1 lần; bot sẽ đẩy nó lên Redis. Xong thì xóa `data.json` khỏi repo.
- Thiếu `UPSTASH_REDIS_REST_*` thì bot vẫn chạy nhưng dữ liệu **sẽ mất** mỗi lần Render khởi động lại.
- Lộ token (vd dán vào repo công khai) → vào Developer Portal bấm **Reset Token**, rồi cập nhật lại biến `DISCORD_TOKEN`.
